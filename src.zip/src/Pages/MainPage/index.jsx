import { BsFillQuestionCircleFill } from "react-icons/bs"
import Header from "../../Common/Header";

import { getParamsFromUrl } from "../../utilities";
import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react'
import './Dashboard.css'
import RightBar from '../../components/RightBar/RightBar'
import { useRecoilValue,useRecoilState } from 'recoil'
import userState from '../../recoil/user'
import { callApi } from '../../services/api'
import { ReactComponent as CircleFillIcon } from '../../assets/circle-fill-icon.svg'
import { ReactComponent as ArrowUpIcon } from '../../assets/arrow-up-icon.svg'
import { ReactComponent as CircleMutedIcon } from '../../assets/circle-mutes-icon.svg'

import axios from 'axios'
import * as XLSX from 'xlsx/xlsx.mjs'
import './ProductHunter.css'
import categoriesJson from '../../mocks/MockCategoryData.js'
import { useForm } from 'react-hook-form'
import Loader from '../../components/Loader/Loader'
import AgGrid from '../../components/AgGrid/AgGrid'
// import ProductSearchFilters from '../ProductSearchFilters/ProductSearchFilters.js'
import SmallCheckbox from '../../components/SmallCheckbox/SmallCheckbox'
import ErrorMessage from '../../components/ErrorMessage/ErrorMessage'
import FormControl from '@mui/material/FormControl'
import Button from '@mui/material/Button'
import FormGroup from '@mui/material/FormGroup'
import FormControlLabel from '@mui/material/FormControlLabel'
import { PRODUCT_HUNTER_GRID_OPTIONS } from './ProductHunterGridOptions'
import { useNavigate, Link, useParams } from 'react-router-dom'
import Tooltip from '../../components/Tooltip/Tooltip'
import Dropdown from '../../components/Dropdown/Dropdown'
import RadioButton from '../../components/RadioButton/RadioButton'

/* TODO: add functionality to persist form values in browser storage */
const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'
const MainPage = () => {
	
	const [orderMatrix, setOrderMatrix] = useState([])
	const userinfo=JSON.parse(localStorage.getItem('userInfo'))

	const [loader, setLoader] = useState(false)
	const user = useRecoilValue(userState)
	const today = new Date()
	const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
	const sevenDaysAgoFormatted =
		sevenDaysAgo.getMonth() +
		1 +
		'/' +
		sevenDaysAgo.getDate() +
		'/' +
		sevenDaysAgo.getFullYear()
	const todayFormatted =
		today.getMonth() + 1 + '/' + today.getDate() + '/' + today.getFullYear()

	useEffect(() => {
		getMatrix()
	}, [])

	const getMatrix = async () => {
		const payload = await callApi(
			'GET',
			`/api/sales/order-metrics?granularity=week`
		)
		setOrderMatrix(payload)
	}

	const { searchInput } = useParams()
	const [isSearchInput, setIsSearchInput] = useState(false)
	const [error, setError] = useState(false)
	const categoriesSplit = []
	const [loading, setLoading] = useState(false)
	const [showForm, setShowForm] = useState(true)

	const [searchType, setSearchType] = useState({
		label: 'Keyword',
		icon: null,
		value: 'keyword',
		tooltip: 'Enter comma-separated keywords describing your product',
		placeholder: 'videogames, silverware, etc.',
	})
	const [marketplace, setMarketplace] = useState({
		label: 'US',
		icon: 'fi fi-us',
		value: 'ATVPDKIKX0DER',
	})
	const { register, handleSubmit } = useForm()
	const [selectedCategory, setSelectedCategory] = useState([])
	const [identifiers, setIdentifiers] = useState('')

	const [searchResults, setSearchResults] = useState([])
	const [fileName, setFileName] = useState('exportedData_' + Date.now())
	const history = useNavigate()

	const downloadExcel = (data) => {
		// https://stackoverflow.com/questions/70871254/how-can-i-export-a-json-object-to-excel-using-nextjs-react
		const worksheet = XLSX.utils.json_to_sheet(data)
		const workbook = XLSX.utils.book_new()
		XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1')
		// let buffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'buffer' });
		// XLSX.write(workbook, { bookType: 'xlsx', type: 'binary' });
		XLSX.writeFile(workbook, 'ProductHunterResults.xlsx')
	}

	const token=userinfo.token
	//const payload = ""

	const getProducts = () => {
		const headers = {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`,
		}
		const payload = JSON.stringify({
			marketplaceIds:"ATVPDKIKX0DER",
			identifiers: "keyword",
			identifiersType:"keyword",
			keywords:["socks"],
			brandNames: "",
			region: 'na',
			pageSize: 20,
		})

		const url = HYPER_API_BASE_URL + '/api/catalog-items/search'
		setLoading(true)
		axios
			.post(url, payload, { headers })
			.then((response) => {
				const res=response.data
				return "hhh"
				//console.log(response.data)
				//setSearchResults(response.data)
				//setLoading(false)
				//setError(false)
			})
			.catch((err) => {
				return ""
			})
			.finally(() => "")
	}

	useEffect(() => {
		setSearchResults("Here");
	}, []);
  
	const marketplaces = [
		{ label: 'US', icon: 'fi fi-us', value: 'ATVPDKIKX0DER' },
		{ label: 'Canada', icon: 'fi fi-ca', value: 'A2EUQ1WTGCTBG2' },
		{ label: 'Mexico', icon: 'fi fi-mx', value: 'A1AM78C64UM0Y8' },
		{ label: 'Brazil', icon: 'fi fi-br', value: 'A2Q3Y263D00KWC' },
	]

	const searchTypes = [
		{
			label: 'Keyword',
			icon: null,
			value: 'keyword',
			defaultChecked: true,
			tooltip: 'Enter comma-separated keywords describing your product',
			placeholder: 'videogames, silverware, etc.',
		},
		{
			label: 'ASIN',
			icon: null,
			value: 'asin',
			defaultChecked: false,
			tooltip: 'Enter comma-separated ASIN identifiers',
			placeholder: 'B07XP5W7ZN, B085LJ7D2S, etc.',
		},
		{
			label: 'GTIN',
			icon: null,
			value: 'gtin',
			defaultChecked: false,
			tooltip: 'Enter comma-separated GTIN identifiers',
			placeholder: '013440318905, 01617561205 , etc.',
		},
		{
			label: 'UPC',
			icon: null,
			value: 'upc',
			defaultChecked: false,
			tooltip: 'Enter comma-separated UPC identifiers',
			placeholder: '',
		},
	]

	const loadingSection = useRef(null)

	const scrollDown = () => {
		window.scrollTo({
			top: loadingSection.current.offsetTop,
			behavior: 'smooth',
		})
	}

	useEffect(() => {
		// scroll to grid view when screen "size < 1025px" small or mobile tablet view
		if (window.innerWidth < 1025 && loading) {
			scrollDown()
		}
	}, [loading])
	// TODO: region should be user's region they select when registering or by location services
	//const ctestc=getProducts(payload)
		/*const [count, setCount] = useState(ctestc.data)

	// Similar to componentDidMount and componentDidUpdate:
	useEffect(() => {
	  // Update the document title using the browser API
	  document.title = `You clicked ${count} times`;
	});*/
  
	return (
		<>
			<section className="body-cont1">		
				<div className="container pt-5 pb-4">
					<div className="row">
						<div className="col-lg-9 cardleft-panel">
							<div className="pt-2 text-2xl mx-auto">
								<p className="font-normal1">
									{searchResults}
									Hello, {userinfo.firstName}! Here's your overview for the Last 7 Days
									{
										<span className="text-gray-400 text-base">
											({sevenDaysAgoFormatted} - {todayFormatted})
										</span>
									}
								</p>
							</div>

							<div className="row">
								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>Total Sales</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">0% vs previous period</div>
										<div className="brd-card"></div>
									</div>
								</div>

								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>Total Profit</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">
											<span className="text-green d-flex">
												<ArrowUpIcon /> 100%
											</span>{' '}
											vs previous period
										</div>
										<div className="brd-card"></div>
									</div>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>Units Sold</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">0% vs previous period</div>
										<div className="brd-card"></div>
									</div>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>ROI</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">0% vs previous period</div>
										<div className="brd-card"></div>
									</div>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>Net Margin</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">
											1.08k% vs previous period
										</div>
										<div className="brd-card"></div>
									</div>
								</div>
								<div className="col-lg-4 col-md-6 col-sm-6">
									<div className="card p-4">
										<div className="d-flex justify-content-between card-title">
											<h4>Average Sales Price</h4>
											<CircleFillIcon />
										</div>
										<div className="card-price">
											<small>$</small>0
										</div>
										<div className="price-txtsort">0% vs previous period</div>
										<div className="brd-card"></div>
									</div>
								</div>
							</div>
							<p className="align-items-center d-flex text-warning">
								Add or update your product costs <CircleMutedIcon />
							</p>
							<div className="card p-4">
								<div className="row">
									<div className="col-md-5">
										<p>Pay per click (PPC) Advertising</p>
									</div>
									<div className="col-md-7">
										<h3>Track the Performance of Your Advertising</h3>
										<p>
											Sync your pay-per-click (PPC) data to better understand
											how your advertising activities impact your sales and
											bottom line.
										</p>
										<button className="btn btn-warning">Sync your data</button>
									</div>
								</div>
							</div>
						</div>
						<RightBar />
						{searchResults}
					</div>
				</div>
			
			</section>
		</>
	)
}

export default MainPage