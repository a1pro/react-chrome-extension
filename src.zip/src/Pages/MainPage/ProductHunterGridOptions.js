import React from 'react'
import Star from '../../assets/star.png'
import numberWithCommas from '../../utils/helpers/number-formatter.util'

export const PRODUCT_HUNTER_GRID_OPTIONS = {
	rowData: [],
	defaultColDef: {
		// flex: 1,
		// minWidth: 100,
		sortable: true,
		// filter: true,
		minHeight: 100,
		Height: 120,
	},
	columnDefs: [
		{
			headerName: '',
			field: 'action',
			width: 50,

			cellRenderer: (params) => {
				return (
					<>
						<button className="t-dot">
							<img src="ico/three-dot.png" />
						</button>
					</>
				)
			},
		},
		{
			headerComponentParams: {
				template: `<span>Product Title <span className="SubTitle">ASIN</span></span>`,
			},
			width: 435,
			field: 'image',
			cellRenderer: (params) => {
				return (
					<div className="big-col">
						{' '}
						<a
							href={params.data?.link}
							target="_blank"
							className="col-wrap"
							rel="noreferrer"
						>
							<span className="img-wrap">
								<img src={params.data?.images[0].link} />
							</span>
							<div className="info-wrap">
								<p> {params.data?.name}</p>
								<span className="sub-wrap">
									<div
										onClick={() => window.open(`/product/${params.data?.asin}`)}
									>
										{params.data?.asin}
									</div>
								</span>
							</div>
							{/* <span className="a-pan">
              <img src="ico/a-sign.png" />
              </span> */}
						</a>
					</div>
				)
			},
		},
		// { headerName: 'Monthly Revenue', field: "revenue" , unSortIcon: true , width: 170,  valueGetter: params => params.data.revenue.value,
		// valueFormatter: params => `$${params.value}`},
		// { headerName: 'Monthly Sales', field: "monthlySales" , unSortIcon: true, width: 150},
		// { headerName: 'Weekly Sales', field: "weeklySales" , unSortIcon: true, width: 150},
		{
			headerName: 'Group Rank',
			field: 'groupRank',
			unSortIcon: true,
			width: 150,
			cellRenderer: (params) => {
				let groupRankTitle
				let groupRank
				let notAvailable
				if (
					params.data?.salesRanks[0]?.displayGroupRanks[0]?.title &&
					params.data?.salesRanks[0]?.displayGroupRanks[0]?.rank
				) {
					groupRankTitle =
						params.data.salesRanks[0]?.displayGroupRanks[0]?.title
					groupRank = params.data.salesRanks[0]?.displayGroupRanks[0]?.rank
				} else {
					notAvailable = 'N/A'
				}
				return (
					<div className="rank-cell-container">
						{!notAvailable ? (
							<>
								<div style={{ fontWeight: 600 }}>{`${
									groupRankTitle || notAvailable
								}`}</div>
								<div style={{ fontWeight: 400 }}>
									{groupRank ? `# ${numberWithCommas(groupRank)}` : ''}
								</div>
							</>
						) : (
							<div>{notAvailable}</div>
						)}
					</div>
				)
			},
		},
		{
			headerName: 'Classification Rank',
			field: 'classificationRank',
			unSortIcon: true,
			width: 150,
			cellRenderer: (params) => {
				let classificationRankTitle
				let classificationRank
				let notAvailable
				if (
					params.data?.salesRanks[0]?.classificationRanks[0]?.title &&
					params.data?.salesRanks[0]?.classificationRanks[0]?.rank
				) {
					classificationRankTitle =
						params.data.salesRanks[0]?.classificationRanks[0]?.title
					classificationRank =
						params.data.salesRanks[0]?.classificationRanks[0]?.rank
				} else {
					notAvailable = 'N/A'
				}

				return (
					<div className="rank-cell-container">
						{!notAvailable ? (
							<>
								<div
									style={{ fontWeight: 600 }}
								>{`${classificationRankTitle}`}</div>
								<div style={{ fontWeight: 400 }}>
									{`# ${numberWithCommas(classificationRank)}`}
								</div>
							</>
						) : (
							<div>{notAvailable}</div>
						)}
					</div>
				)
			},
		},
		{
			headerName: 'Price',
			width: 150,
			field: 'price',
			cellRenderer: (params) => {
				let priceText
				if (params.data?.price) {
					priceText = params.data.price
				} else {
					priceText = 'N/A'
				}
				return (
					<div className="price-pan">
						<div>{`${priceText}`}</div>
					</div>
				)
			},
			unSortIcon: true,
			comparator: (valueA, valueB, nodeA, nodeB, isDescending) =>
				valueA - valueB,
		},
		{
			headerName: 'Rating',
			field: 'rating',
			cellRenderer: (params) => {
				let ratingsText
				if (params.data?.rating) {
					ratingsText = params.data.rating
				} else {
					ratingsText = 'N/A'
				}
				return (
					<div className="rating">
						<div style={{ alignSelf: 'center' }}>{`${ratingsText}`}</div>
						<img
							src={Star}
							style={{ marginBottom: '0.4rem', marginLeft: '0.2rem' }}
						/>
					</div>
				)
			},
			cellClass: 'ag-right-aligned-cell',
			unSortIcon: true,
			width: 150,
		},
		{
			headerName: 'Total Ratings',
			field: 'ratingsTotal',
			cellRenderer: (params) => {
				let totalRatingsText
				if (params.data?.ratingsTotal) {
					totalRatingsText = numberWithCommas(params.data.ratingsTotal)
				} else {
					totalRatingsText = 'N/A'
				}

				return (
					<div className="price-pan">
						<div>{`${totalRatingsText}`}</div>
					</div>
				)
			},
			unSortIcon: true,
			width: 150,
		},
		// { headerName: 'LQS', field: "lqs", unSortIcon: true , width: 100 },
	],
	pagination: true,
	ref: null,
	animateRows: true,
	rowHeight: 100,
	onRowClicked: (event) => console.log('A row was clicked'),
	onColumnResized: (event) => console.log('A column was resized'),
	onGridReady: (event) => console.log('The grid is now ready!\n', event),
	// CALLBACKS
	onCellClicked: (event) => console.log('cell clicked'),
}
