import { callApi } from '../../services/api'
export const createPaymentIntent = async (type) => {
	const subscriptionTypeBesic = 'price_1LUhdkGwlsjAN6jK6x7vUlAH'
	const subscriptionTypeSuite = 'price_1LTVITGwlsjAN6jKT1wQ7wwi'
	const userId = localStorage.getItem('userInfo')
		? JSON.parse(localStorage.getItem('userInfo')).data._id
		: null
	let price = ''
	if (String(type) === 'basic') {
		price = subscriptionTypeBesic
	} else if (String(type) === 'suite') {
		price = subscriptionTypeSuite
	}

	// parameterize user id
	const payload = {
		lineItems: [{ price, quantity: 1 }],
		userId,
		mode: 'subscription',
	}

	const url = `/api/payment/create-checkout-session`

	const response = await callApi('POST', url, payload)
	if (response.data) {
		localStorage.setItem('subscriptionType', type)
		window.location.href = response.data.url
	} else {
		window.location.href = '/pricing'
	}
}
