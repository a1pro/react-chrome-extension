export const getRouteQueryParamsString = (oldQueryString, key, value) => {
	const queryParams = new URLSearchParams(oldQueryString)
	queryParams.set(key, value)
	return queryParams.toString()
}
