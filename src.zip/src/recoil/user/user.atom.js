import { atom } from 'recoil'

export const userState = atom({
	key: 'userAtom',
	default: {
		_id: '0',
		firstName: 'default',
		lastName: 'last',
		email: 'default@email.com',
		permissions: ['FREE'],
		role: '',
		token: '',
	},
	effects: [
		({ onSet }) => {
			onSet((newID) => {
				console.debug('Current user:', newID)
			})
		},
	],
})
