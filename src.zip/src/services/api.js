import axios from 'axios'

const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

export function callApi(...params) {
	let data = null
	const method = params[0]
	const url = params[1] || ''
	const postData = params[2] || {}
	const token = localStorage.getItem('userInfo')
		? JSON.parse(localStorage.getItem('userInfo')).data?.token
		: null

	const reqHeaders = {
		'Content-Type': 'application/json',
	}
	if (token) {
		reqHeaders.Authorization = 'Bearer ' + token
	}

	const instance = axios.create({
		headers: reqHeaders,
	})

	let result = ''
	let bodydata = {}
	switch (method) {
		case 'POST':
			bodydata = JSON.stringify(postData)
			result = instance.post(HYPER_API_BASE_URL + url, bodydata)
			break

		case 'PUT':
			bodydata = JSON.stringify(postData)
			result = instance.put(HYPER_API_BASE_URL + url, bodydata)
			break

		case 'PATCH':
			bodydata = JSON.stringify(postData)
			result = instance.patch(HYPER_API_BASE_URL + url, bodydata)
			break

		case 'DELETE':
			bodydata = JSON.stringify(postData)
			result = instance.delete(HYPER_API_BASE_URL + url, bodydata)
			break

		case 'GET':
			data = getParams(postData)
			if (data) {
				result = instance.get(`${HYPER_API_BASE_URL}${url}?${data}`)
			} else {
				result = instance.get(HYPER_API_BASE_URL + url)
			}
			break

		default:
			result = instance.get(HYPER_API_BASE_URL + url)
			break
	}
	return result
}

function getParams(data) {
	return Object.keys(data)
		.map((key) => `${key}=${encodeURIComponent(data[key])}`)
		.join('&')
}
