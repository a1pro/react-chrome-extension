import React from 'react'

const SmallCheckbox = ({ label, checked = false, onClick, boxValue }) => {
	return (
		<div className="flex justify-center">
			<div className="flex flex-col items-start">
				<div className="pt-1 pl-3 flex items-center">
					<div className="bg-white dark:bg-gray-800 border rounded-sm border-gray-400 dark:border-gray-700 w-4 h-4 flex flex-shrink-0 justify-center items-center relative">
						<input
							type="checkbox"
							defaultChecked={checked}
							className="checkbox opacity-0 absolute cursor-pointer w-full h-full"
							value={boxValue || 'None'}
							onClick={(event) => onClick(event)}
						/>
						<div
							className="check-icon hidden text-white"
							style={{ backgroundColor: '#19aadb' }}
						>
							<svg
								className="icon icon-tabler icon-tabler-check"
								xmlns="http://www.w3.org/2000/svg"
								width={16}
								height={16}
								viewBox="0 0 24 24"
								strokeWidth="1.5"
								stroke="currentColor"
								fill="none"
								strokeLinecap="round"
								strokeLinejoin="round"
							>
								<path stroke="none" d="M0 0h24v24H0z" />
								<path d="M5 12l5 5l10 -10" />
							</svg>
						</div>
					</div>
					<p className="ml-3 text-sm leading-4 font-normal text-gray-800 dark:text-gray-100">
						{label}
					</p>
				</div>
			</div>
			<style>
				{`  .checkbox:checked + .check-icon {
                            display: flex;
                        }`}
			</style>
		</div>
	)
}

export default SmallCheckbox
