import React from 'react'
import NewsUpdateThumbnail from '../../assets/banner-thumbnail.jpg'
import { ReactComponent as NewsFeature } from '../../assets/news-feature-arrow.svg'
import './RightBar.css'

const RightBar = () => {
	return (
		<>
			<div className="col-lg-3 cardright-panel">
				<div className="card p-4">
					<h2>News & Updates</h2>
					<div className="card news-item item-w-3">
						<a href="#" target="_blank">
							<img
								src={NewsUpdateThumbnail}
								className="w-100"
								alt="thumbnail"
							/>
						</a>
						<div className="card">
							<h4>
								<a className="d-flex justify-content-between" href="#">
									News Feature
									<NewsFeature />
								</a>
							</h4>
							<p>Track your PPC campaigns with Advertising analytics </p>
						</div>
					</div>
					<div className="card news-item item-w-3">
						<div className="card">
							<h4>
								<a className="d-flex justify-content-between" href="#">
									Product Updates
									<NewsFeature />
								</a>
							</h4>
							<p>Track your PPC campaigns with Advertising analytics </p>
						</div>
					</div>
					<div className="card news-item item-w-3">
						<div className="card">
							<h4>
								<a className="d-flex justify-content-between" href="#">
									Amazon News
									<NewsFeature />
								</a>
							</h4>
							<p>Track your PPC campaigns with Advertising analytics </p>
						</div>
					</div>

				</div>
				<div class="upcoming_events">
				<h2>Upcoming Events</h2>
					<div className="card news-item">
						<div className="card">
							<h4>
								<a className="d-flex justify-content-between" href="#">
									Tool Tip Tuesday
									<NewsFeature />
								</a>
							</h4>
							<p>Register now</p>
						</div>
					</div>
					</div>
			</div>
		</>
	)
}
export default RightBar
