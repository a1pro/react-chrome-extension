import React from 'react'
import FormControl from '@mui/material/FormControl'
import InputLabel from '@mui/material/InputLabel'
import { OutlinedInput } from '@mui/material'
import { Row, Col } from 'react-bootstrap'
// import FormLabel from '@mui/material/FormLabel';
import './ProductSearchFilters.css'

const ProductSearchFilters = () => {
	return (
		<>
			<div className="column-container">
				<Row className="row-container">
					<div className="filter-title">Price</div>
					{/* TODO: figure out why this class is not setting display flex properly */}
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Net</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Rank</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Sales</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Revenue</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
			</div>
			<div className="column-container">
				<Row className="row-container">
					<div className="filter-title">No. of Reviews</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Rating(1-5)</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">Weight</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">No. of Sellers</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
				<Row className="row-container">
					<div className="filter-title">LQS(1-10)</div>
					<div className="input-container">
						<Col>
							<FormControl>
								<InputLabel htmlFor="min-price-input">Min</InputLabel>
								<OutlinedInput
									id="min-price-input"
									aria-describedby="min price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
						<Col>
							<FormControl>
								<InputLabel htmlFor="max-price-input">Max</InputLabel>
								<OutlinedInput
									id="max-price-input"
									aria-describedby="max price"
									defaultValue={0}
								/>
							</FormControl>
						</Col>
					</div>
				</Row>
			</div>
		</>
	)
}

export default ProductSearchFilters
