import React from 'react'
import './RadioButton.css'

const RadioButton = ({ items = [], onSelect }) => {
	const radioGroup = items.map((item) => {
		return (
			<div key={item.value} className="flex items-center">
				<div className="bg-white dark:bg-gray-100 rounded-full w-5 h-5 flex flex-shrink-0 justify-center items-center relative">
					<input
						defaultChecked={item.defaultChecked}
						type="radio"
						name="radio"
						value={item.value}
						onClick={() => onSelect(item)}
						className="radio appearance-none focus:outline-none border rounded-full border-gray-400 absolute cursor-pointer w-full h-full checked:border-none"
					/>
					<div className="check-icon hidden border-4 border-hyper-blue rounded-full w-full h-full z-1" />
				</div>
				<p className="radio-label mt-1 text-sm leading-4 font-normal text-gray-800 dark:text-gray-300">
					{item.label}
				</p>
			</div>
		)
	})

	return <div className="flex">{radioGroup}</div>
}
export default RadioButton
