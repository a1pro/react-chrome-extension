import { React, useState } from 'react'
import ArrowSvg from '../../assets/arrow-ico.png'
import './MainItem.css'
const MainItem = (props) => {
	const [mainImg, setMainImg] = useState(
		Object.values(props.searchData.images)[0].link
	)
	const [itemImgs, setItemImgs] = useState(props.itemImgs)
	return (
		<div className="m-auto flex flex-col justify-between items-center py-3 w-11/12 md:flex-row-reverse lg:w-10/12">
			<div className="right-body">
				<div className="product-info-container">
					<h1 className="product-name">{props.searchData.name}</h1>
					<div className="product-price-container hidden justify-arount flex-col items-center box-border p-3 md:flex">
						<div className="flex flex-row justify-between items-center w-full lg:flex-row lg:items-center md:flex-col md:items-start">
							<div className="product-price flex items-center">
								<h2 className="font-extrabold m-0 text-black text-2xl lg:text-4xl">
									{props.searchData.price}
								</h2>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="left-body">
				<div className="flex flex-col-reverse justify-between items-center lg:flex-row">
					<div className="imgs-holder flex flex-col item-start">
						<button
							onClick={() => {
								const Data = itemImgs.slice()
								Data.push(Data.shift())
								setItemImgs(Data)
							}}
						>
							<img src={ArrowSvg} alt="arrow_img" />
						</button>
						<div className="slider-img-holder flex flex-col justify-between items-start overflow-hidden">
							{itemImgs.map((el) => {
								return (
									<img
										onClick={(e) => {
											setMainImg(e.target.src)
										}}
										src={el}
										alt="productImg"
										key={Math.random()}
									/>
								)
							})}
						</div>
						<button
							onClick={() => {
								const Data = itemImgs.slice()
								Data.unshift(Data.pop())
								setItemImgs(Data)
							}}
						>
							<img
								src={ArrowSvg}
								alt="arrow_img"
								style={{ transform: 'rotate(180deg)' }}
							/>
						</button>
					</div>
					<div className="main-product-img w-10/12">
						<img
							className="m-auto w-full lg:ml-3.5 lg:mr-auto"
							src={mainImg}
							alt="s"
						/>
					</div>
				</div>
				<div
					className="product-price-container flex justify-arount flex-col items-center box-border p-3 mobile"
					style={{ display: 'none' }}
				>
					<div className="flex flex-row justify-between items-center w-full lg:flex-row lg:items-center md:flex-col md:items-start">
						<div className="product-price flex items-center">
							<h2 className="font-extrabold m-0 text-black text-2xl lg:text-4xl">
								{props.searchData.price}
							</h2>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default MainItem
