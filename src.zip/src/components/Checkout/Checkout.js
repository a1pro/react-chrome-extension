import React, { useEffect, useState } from 'react'
import './Checkout.css'
import CheckoutForm from '../CheckoutForm/CheckoutForm'
import userState from '../../recoil/user'
import { useRecoilValue } from 'recoil'
import axios from 'axios'
import { Elements } from '@stripe/react-stripe-js'
import { loadStripe } from '@stripe/stripe-js'
/*
 * Premium product: Premium service with extra features
 * $10.00 USD / month
 */
const PRICE_LOOKUP_KEY = 'price_1LUhdkGwlsjAN6jK6x7vUlAH'

const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

// Make sure to call `loadStripe` outside of a component’s render to avoid
// recreating the `Stripe` object on every render.
const stripePromise = loadStripe(
	'pk_test_51LQBJhGwlsjAN6jKNrE9UHLxdy4r6GNtuRksq0TOcf7TY0qiofPxAxSZnClfxoh32Jx2Q6BjdaBczOeiAIuCwFVL0083CLAmpB'
)

const Checkout = () => {
	// const stripe = useStripe()
	// const elements = useElements()
	const [clientSecret, setClientSecret] = useState('')
	const [orderId, setOrderId] = useState(null)
	const [message, setMessage] = useState(null)
	const [isLoading, setIsLoading] = useState(false)
	const user = useRecoilValue(userState)
	/*
	 *	I was trying to create an order on this dashboard page to mimic the creation of an order in a checkout flow.
	 *	I think this createOrder call would be made on "Checkout" button click(when user official has intent).
	 *	Once we get the response, we need the orderId in order to call createPaymentIntent in App.js
	 * 	I was thinking after the successful createOrder call to set the order id in state in a new orders atom.
	 * 	We should prob move what I have in App.js to a lower order component like Checkout.js and move whats in checkout to a child like <CheckoutForm />
	 *	so we dont have to do this at the root.
	 *	Once we create payment, we want to confirm(see CheckoutForm.jsx here: https://stripe.com/docs/payments/quickstart) the payment and route the user to a success page or display a success message.
	 *
	 */

	const token = localStorage.getItem('userInfo')
		? JSON.parse(localStorage.getItem('userInfo')).data.token
		: null
	const userId = localStorage.getItem('userInfo')
		? JSON.parse(localStorage.getItem('userInfo')).data._id
		: null
	const name = localStorage.getItem('userInfo')
		? JSON.parse(localStorage.getItem('userInfo')).data.firstName
		: null
	const createOrder = () => {
		console.log('Current user\n', user)
		const headers = {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`,
		}
		// This is the necessary payload for call - confirmed types; user could have discrepancies with new firstName & lastName properties
		const payload = JSON.stringify({
			items: [
				{ name: 'Basic', price: 14.99 },
				{ name: 'Best Value', price: 24.99 },
				{ name: 'Premium', price: 44.99 },
			],
			currency: 'usd',
			userId,
			name,
		})
		const url = HYPER_API_BASE_URL + '/api/order'
		axios
			.post(url, payload, { headers })
			.then((response) => {
				console.log('Order response\n', response.data.order)
				setOrderId(response?.data.order._id)
				createPaymentIntent(response?.data.order._id)
			})
			.catch((err) => {
				console.log(err)
			})
	}

	const createPaymentIntent = (id) => {
		const headers = {
			'Content-Type': 'application/json',
			Authorization: `Bearer ${token}`,
		}
		// parameterize user id
		const payload = JSON.stringify({
			lineItems: [{ price: 'price_1LUhdkGwlsjAN6jK6x7vUlAH', quantity: 5 }],
			userId,
		})
		// HYPER_API_BASE_URL
		const url = 'http://localhost:3000' + `/api/payment/create-checkout-session`
		axios
			.post(url, payload, { headers })
			.then((response) => {
				window.location.href = response.data.url
			})
			.catch((err) => {
				console.log(err)
			})
	}

	const handleSubmit = (event) => {
		event.preventDefault()
		console.log('Calling createOrder()\n', event)
		createOrder()
	}

	const appearance = {
		theme: 'stripe',
	}

	const options = {
		clientSecret,
		appearance,
	}

	return (
		<>
			<form className="mt-24 ml-24 w-24 h-24" onSubmit={handleSubmit}>
				<button>Create Order</button>
			</form>
			{clientSecret && orderId && (
				<Elements stripe={stripePromise} options={options}>
					<CheckoutForm orderId={orderId} />
				</Elements>
			)}
		</>
	)
}

export default Checkout
