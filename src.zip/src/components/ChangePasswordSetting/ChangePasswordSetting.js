import React, { useEffect, useState } from 'react'
import axios from 'axios'
import FormControl from '@mui/material/FormControl'
import Button from '@mui/material/Button'
import { useForm } from 'react-hook-form'
import { useRecoilValue, useSetRecoilState } from 'recoil'
import userState from '../../recoil/user'
import ErrorMessage from '../ErrorMessage/ErrorMessage'

const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

const ChangePasswordSetting = () => {
	const { register, handleSubmit, reset } = useForm({
		defaultValues: {
			oldPassword: '',
			newPassword: '',
		},
	})
	const [loading, setLoading] = useState(false)
	const [error, setError] = useState('')

	const onSubmit = (data) => {
		if (data.oldPassword.length === 0 || data.newPassword.length === 0) {
			setError('Old password and new password cannot be empty string')
			return
		}
		if (data.oldPassword === data.newPassword) {
			setError('Old and new passwords are same')
			return
		}

		const userInfo = localStorage.getItem('userInfo')
			? JSON.parse(localStorage.getItem('userInfo'))
			: null

		const payload = {
			oldPassword: data.oldPassword,
			newPassword: data.newPassword,
		}

		setLoading(true)
		axios
			.patch(
				`${HYPER_API_BASE_URL}/api/users/permissions/update-password`,
				payload,
				{
					headers: {
						Authorization: `Bearer ${userInfo.token}`,
					},
				}
			)
			.then(() => {
				setLoading(false)
			})
			.catch((err) => {
				setLoading(false)
				setError(
					err.response.data.message || 'Some error happened. Please try again'
				)
			})
	}

	useEffect(() => {
		if (error.length > 0) {
			setTimeout(() => {
				setError('')
			}, 3000)
		}
	}, [error])

	return (
		<div className="w-full flex flex-col items-start gap-y-2">
			{error.length > 0 && (
				<div className="w-full flex justify-center">
					<ErrorMessage>{error}</ErrorMessage>
				</div>
			)}
			<h1 className="text-xl font-medium pr-2 leading-5 text-gray-800">
				Passwords
			</h1>
			<div className="w-full flex flex-col lg:flex-row gap-y-3 lg:gap-x-6">
				<p className="text-sm leading-5 text-gray-600 w-full lg:w-80 flex-none">
					Change the password you use to log in to the account
				</p>
				<form
					onSubmit={handleSubmit(onSubmit)}
					className="w-full flex flex-col gap-y-5 bg-white border border-solid border-gray-700 rounded-sm px-3 py-2 md:px-4 md:py-3 lg:px-6 lg:pt-5 lg:pb-7"
				>
					<div className="w-full flex flex-col gap-y-3 pt-2">
						<div className="w-full flex flex-col md:flex-row md:justify-between gap-y-2 md:gap-x-3">
							<FormControl className="flex-grow">
								<div className="flex flex-col gap-y-1">
									<label
										className="text-sm leading-none text-gray-800"
										htmlFor="oldPassword"
									>
										Old Password
									</label>
									<input
										id="oldPassword"
										type="password"
										{...register('oldPassword')}
										className="w-full max-w-md p-3 mt-1 bg-gray-100 border rounded border-gray-200 focus:outline-none focus:border-gray-600 text-sm  leading-none text-gray-800"
									/>
								</div>
							</FormControl>
							<FormControl className="flex-grow">
								<div className="flex flex-col gap-y-1">
									<label
										className="text-sm leading-none text-gray-800"
										htmlFor="newPassword"
									>
										New Password
									</label>
									<input
										id="newPassword"
										type="password"
										{...register('newPassword')}
										className="w-full max-w-md p-3 mt-1 bg-gray-100 border rounded border-gray-200 focus:outline-none focus:border-gray-600 text-sm  leading-none text-gray-800"
									/>
								</div>
							</FormControl>
						</div>
					</div>
					<div className="flex items-center justify-between md:justify-end gap-x-1 md:gap-x-3">
						<Button
							type="button"
							onClick={() => {
								reset({
									oldPassword: '',
									newPassword: '',
								})
							}}
							className="form-button bg-transparent outline outline-1 hover:outline-2 active:outline-2 focus:outline-none focus:ring focus:ring-hyper-dark-blue h-12"
						>
							<span className="font-[400] leading-6">Reset</span>
						</Button>
						<Button
							type="submit"
							disabled={loading}
							className="form-button bg-light-green hover:bg-green active:bg-green focus:outline-none focus:ring focus:ring-green h-12"
						>
							<span className="font-[600] leading-6 text-white">
								{loading ? 'Saving...' : 'Submit'}
							</span>
						</Button>
					</div>
				</form>
			</div>
		</div>
	)
}

export default ChangePasswordSetting
