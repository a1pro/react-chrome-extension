import React from 'react'
import ReactPlayer from 'react-player'

const VideoPlayer = () => {
	return (
		<div className="player-container">
			<ReactPlayer
				url="https://player.vimeo.com/video/730205713?h=950b4ac04d&amp;muted=1&amp;autoplay=1&amp;loop=1&amp;transparent=0&amp;background=1&amp;app_id=122963"
				config={{
					vimeo: {
						playerOptions: {
							autopause: false,
							background: true,
							byline: false,
							controls: false,
							loop: true,
							muted: true,
							responsive: true,
							title: false,
						},
					},
				}}
				playing={true}
				loop={true}
				muted={true}
				playsinline
				width={'100%'}
				height={'auto'}
			/>
		</div>
	)
}

export default VideoPlayer
