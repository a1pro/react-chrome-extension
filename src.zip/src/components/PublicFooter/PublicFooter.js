import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import logowhite from '../../assets/logo-white.svg'
import logoAmazonwebservice from '../../assets/badge-aws.png'
import './PublicFooter.css'
import axios from 'axios'
import SuccessMessage from '../SuccessMesage/SuccessMessage'
import ErrorMessage from '../ErrorMessage/ErrorMessage'
import { useForm } from 'react-hook-form'

export const PublicFooter = () => {
	const [name, setName] = useState('')
	const [email, setEmail] = useState('')
	const [subject, setSubject] = useState('')
	const [text, setText] = useState('')
	const [success, setSuccess] = useState(null)
	const [error, setError] = useState(null)

	const { reset, handleSubmit } = useForm()

	const submitHandler = async () => {
		try {
			const BASE_URL =
				process.env.HYPER_API_BASE_URL ||
				'https://hyper-api-proto.herokuapp.com'
			const { data } = await axios.post(`${BASE_URL}/api/contact-us`, {
				name,
				email,
				subject,
				message: text,
			})
			setSuccess(data.message)
			reset()
		} catch (err) {
			const errMessage =
				err.response && err.response.data.message
					? err.response.data.message
					: err.message
			setError(errMessage)
		}
	}

	return (
		<>
			<footer>
				<div className="container">
					<div className="frow">
						<div className="fcol-left">
							<Link
								to="/"
								className="flex justify-center md:flex md:justify-start"
							>
								<img src={logowhite}></img>
							</Link>
							<p className="ltext text-justify">
								Join the fastest growing and sharpest toolset in the market.
							</p>
							<Link
								to="/"
								className="request-demo-btn max-w-xs md:max-w-none flex justify-center mx-auto"
							>
								Request your demo
							</Link>
							<img src={logoAmazonwebservice} className="mx-auto" />
						</div>
						<div className="fmenu-col-1">
							<h2 className="ftitle text-center">Quick Links:</h2>
							<ul className="w-fit mx-auto md:mx-0">
								<li>
									<Link to="/">Home</Link>
								</li>
								<li>
									<Link to="/pricing">Pricing</Link>
								</li>
								<li>
									<Link to="/contact">Contact us</Link>
								</li>
							</ul>
						</div>
						<div className="fmenu-col-2">
							<h2 className="ftitle text-center">Follow us:</h2>
							<ul className="w-fit mx-auto md:mx-0">
								<li>
									<a href="https://www.instagram.com/">
										<svg
											width="19"
											height="19"
											viewBox="0 0 19 19"
											fill="none"
											xmlns="http://www.w3.org/2000/svg"
										>
											<path
												d="M13.6396 0.240234H5.76465C2.95215 0.240234 0.702148 2.49023 0.702148 5.30273V8.67773V13.1777C0.702148 15.9902 2.95215 18.2402 5.76465 18.2402H13.6396C16.4521 18.2402 18.7021 15.9902 18.7021 13.1777V8.67773V5.30273C18.7021 2.49023 16.4521 0.240234 13.6396 0.240234ZM9.70215 5.86523C11.5584 5.86523 13.0771 7.38398 13.0771 9.24023C13.0771 11.0965 11.5584 12.6152 9.70215 12.6152C7.8459 12.6152 6.32715 11.0965 6.32715 9.24023C6.32715 7.38398 7.8459 5.86523 9.70215 5.86523ZM13.0771 4.17773C13.0771 3.55898 13.5834 3.05273 14.2021 3.05273C14.8209 3.05273 15.3271 3.55898 15.3271 4.17773C15.3271 4.79648 14.8209 5.30273 14.2021 5.30273C13.5834 5.30273 13.0771 4.79648 13.0771 4.17773Z"
												fill="white"
											/>
										</svg>
										Instagram
									</a>
								</li>
								<li>
									<a to="https://www.youtube.com/">
										<svg
											width="23"
											height="18"
											viewBox="0 0 23 18"
											fill="none"
											xmlns="http://www.w3.org/2000/svg"
										>
											<path
												d="M22.1712 3.1428C21.9191 2.1035 21.176 1.28497 20.2326 1.0072C18.5226 0.502441 11.6658 0.502441 11.6658 0.502441C11.6658 0.502441 4.80897 0.502441 3.09894 1.0072C2.15554 1.28502 1.41252 2.1035 1.16034 3.1428C0.702148 5.02661 0.702148 8.95698 0.702148 8.95698C0.702148 8.95698 0.702148 12.8874 1.16034 14.7712C1.41252 15.8105 2.15554 16.5949 3.09894 16.8727C4.80897 17.3774 11.6658 17.3774 11.6658 17.3774C11.6658 17.3774 18.5226 17.3774 20.2326 16.8727C21.176 16.5949 21.9191 15.8105 22.1712 14.7712C22.6294 12.8874 22.6294 8.95698 22.6294 8.95698C22.6294 8.95698 22.6294 5.02661 22.1712 3.1428ZM9.42321 12.5255V5.38849L15.1542 8.95707L9.42321 12.5255Z"
												fill="white"
											/>
										</svg>
										Youtube
									</a>
								</li>
								<li>
									<a to="https://www.twitter.com/">
										<svg
											width="24"
											height="23"
											viewBox="0 0 24 23"
											fill="none"
											xmlns="http://www.w3.org/2000/svg"
										>
											<path
												d="M11.7021 0.272949C5.42051 0.272949 0.327148 5.17041 0.327148 11.2104C0.327148 17.2505 5.42051 22.1479 11.7021 22.1479C17.9838 22.1479 23.0771 17.2505 23.0771 11.2104C23.0771 5.17041 17.9838 0.272949 11.7021 0.272949ZM17.1687 8.51758C17.1764 8.63232 17.1764 8.75195 17.1764 8.86914C17.1764 12.4531 14.3377 16.5815 9.15039 16.5815C7.55078 16.5815 6.06797 16.1348 4.81875 15.3657C5.04727 15.3901 5.26563 15.3999 5.49922 15.3999C6.81953 15.3999 8.0332 14.9702 9.00059 14.2427C7.76152 14.2183 6.72051 13.437 6.36504 12.3628C6.79922 12.4238 7.19023 12.4238 7.63711 12.314C6.99911 12.1893 6.42566 11.8562 6.01418 11.3711C5.6027 10.8859 5.37858 10.2788 5.37988 9.65283V9.61865C5.75313 9.82129 6.19238 9.9458 6.65195 9.96289C6.26562 9.71532 5.94878 9.37991 5.72954 8.9864C5.5103 8.59289 5.39543 8.15345 5.39512 7.70703C5.39512 7.20166 5.53223 6.74023 5.77852 6.33984C6.48667 7.17807 7.37033 7.86363 8.37208 8.35197C9.37383 8.84031 10.4712 9.12049 11.593 9.17432C11.1943 7.33105 12.6264 5.83936 14.3479 5.83936C15.1604 5.83936 15.8916 6.1665 16.407 6.69385C17.0443 6.5791 17.6537 6.34961 18.1971 6.04199C17.9863 6.66943 17.5445 7.19922 16.958 7.53369C17.5268 7.4751 18.0752 7.32373 18.583 7.11133C18.1996 7.65332 17.7197 8.13428 17.1687 8.51758Z"
												fill="white"
											/>
										</svg>
										Twitter
									</a>
								</li>
							</ul>
						</div>
						<div className="fmenu-col-3">
							<h2 className="ftitle">Send Message:</h2>
							{success && <SuccessMessage>{success}</SuccessMessage>}
							{error && <ErrorMessage>{error}</ErrorMessage>}
							<form onSubmit={handleSubmit(submitHandler)}>
								<div className="form-style">
									{/* <form>
								<label>
									Name:
									<input type="text" />
								</label>
								<input type="submit" value="Submit" />
							</form> */}
									<label>
										Name*
										<div className="brd">
											<input
												type="text"
												placeholder="Enter name"
												value={name}
												onChange={(e) => setName(e.target.value)}
											/>
										</div>
									</label>
									<label>
										Email*
										<div className="brd">
											<input
												type="text"
												placeholder="Enter email address"
												value={email}
												onChange={(e) => setEmail(e.target.value)}
											/>
										</div>
									</label>
									<label>
										Subject*
										<div className="brd">
											<input
												type="text"
												placeholder="Enter subject"
												value={subject}
												onChange={(e) => setSubject(e.target.value)}
											/>
										</div>
									</label>
									<label>
										Message*
										<div className="brd">
											<textarea
												placeholder="Hi Hyper team,"
												value={text}
												onChange={(e) => setText(e.target.value)}
											></textarea>
										</div>
									</label>
									<button className="submit-btn">SEND</button>
								</div>
							</form>
						</div>
						<div className="infomenu">
							<ul className="w-fit">
								<li>
									<Link to="/">Privacy Center</Link>
								</li>
								<li>
									<Link to="/">Privacy Policy</Link>
								</li>
								<li>
									<Link to="/">Terms of Use</Link>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</footer>
			<div className="copyright-sec">
				<div className="container">
					<p>Hyper Copyright 2022. All Rights Reserved</p>
				</div>
			</div>
		</>
	)
}

export default PublicFooter
