import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import './GenericModal.css'
const GenericModal = ({ onSearchSubmit, closeButton = false }) => {
	const [show, setShowModal] = useState(true)
	const { register, handleSubmit } = useForm()

	const onSubmit = async ({ asin }) => {
		onSearchSubmit(asin)
	}

	return (
		<div className="py-12 px-4">
			<div
				className={`${
					show ? 'flex' : 'hidden'
				} mx-auto md:px-6 px-4 lg:py-24 md:py-12 py-9 w-fit`}
			>
				<div className="bg-white lg:max-w-[842px] w-full mx-auto lg:px-10 md:px-6 px-4 md:pt-16 pt-14 pb-6 relative">
					{closeButton && (
						<svg
							onClick={() => setShowModal(!show)}
							className="cursor-pointer absolute right-4 top-4 z-10"
							width={24}
							height={24}
							viewBox="0 0 24 24"
							fill="none"
							xmlns="http://www.w3.org/2000/svg"
						>
							<path
								fillRule="evenodd"
								clipRule="evenodd"
								d="M7.28033 6.21967C6.98744 5.92678 6.51256 5.92678 6.21967 6.21967C5.92678 6.51256 5.92678 6.98744 6.21967 7.28033L10.9393 12L6.21967 16.7197C5.92678 17.0126 5.92678 17.4874 6.21967 17.7803C6.51256 18.0732 6.98744 18.0732 7.28033 17.7803L12 13.0607L16.7197 17.7803C17.0126 18.0732 17.4874 18.0732 17.7803 17.7803C18.0732 17.4874 18.0732 17.0126 17.7803 16.7197L13.0607 12L17.7803 7.28033C18.0732 6.98744 18.0732 6.51256 17.7803 6.21967C17.4874 5.92678 17.0126 5.92678 16.7197 6.21967L12 10.9393L7.28033 6.21967Z"
								fill="#1F2937"
							/>
						</svg>
					)}

					<p className="text-gray-800  font-semibold lg:text-4xl md:text-3xl text-3xl text-center ">
						Enter Product ASIN
					</p>
					<p className="text-center  text-lg text-gray-600 pt-4">
						You can find this 10-digit identifier in the url of any Amazon
						product
					</p>
					<form
						onSubmit={handleSubmit(onSubmit)}
						className="px-2 sm:px-0"
						action="#"
						method="POST"
					>
						<div className="text-center pt-10 md:flex block justify-center gap-2">
							<div className="rounded-md">
								<input
									type="ASIN"
									name
									id="asin"
									{...register('asin')}
									placeholder="BXXXXXXXXX"
									autoComplete="email"
									required
									className="search border focus:outline-none max-w-[405px] w-full px-4 py-3"
								/>
							</div>
							<div className="px-2 sm:px-6 pt-1">
								<button
									type="submit"
									className="search bg-hyper-blue focus:bg-black focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 py-3 text-sm"
								>
									Search
								</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	)
}
export default GenericModal
