import axios from 'axios'
import React, { useState } from 'react'
import { useForm } from 'react-hook-form'
import ErrorMessage from '../ErrorMessage/ErrorMessage'
import SuccessMessage from '../SuccessMesage/SuccessMessage'

const ForgotPassword = () => {
	const [email, setEmail] = useState('')
	const [error, setError] = useState(null)
	const [success, setSuccess] = useState(null)

	const { reset, handleSubmit, register } = useForm()

	const submitHandler = async () => {
		try {
			const BASE_URL =
				process.env.HYPER_API_BASE_URL ||
				'https://hyper-api-proto.herokuapp.com'
			const { data } = await axios.post(`${BASE_URL}/api/forgot-password`, {
				email,
			})
			setSuccess(data.message)
			reset()
		} catch (err) {
			const errMessage =
				err.response && err.response.data.message
					? err.response.data.message
					: err.message
			setError(errMessage)
		}
	}
	return (
		<div className="login-container bg-gray-50 pt-32 pb-8">
			<div className="flex align-items-center justify-center mb-8 w-100">
				<div className="login max-w-2xl w-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
					<div className="max-w-2xl w-full space-y-8">
						<div className="mx-auto flex justify-center lg:items-center h-full">
							<form
								onSubmit={handleSubmit(submitHandler)}
								className="px-2 sm:px-0"
							>
								<div className="w-96 px-2 flex flex-col items-center justify-center">
									<h3 className="text-2xl sm:text-3xl xl:text-2xl font-semibold leading-tight">
										Reset Password
									</h3>
								</div>
								{error && <ErrorMessage>{error}</ErrorMessage>}
								{success && <SuccessMessage>{success}</SuccessMessage>}
								<div className="mt-8 w-full rounded-md shadow-sm -space-y-px ">
									<div>
										<label htmlFor="email-address" className="sr-only">
											Email address
										</label>
										<input
											id="email-address"
											name="email"
											type="email"
											value={email}
											onChange={(e) => setEmail(e.target.value)}
											autoComplete="email"
											required
											className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
											placeholder="Email address"
											// value={email}
										/>
									</div>
								</div>
								<div className="pt-6 w-full flex justify-between px-2 sm:px-6"></div>
								<div className="px-2 sm:px-6">
									<button className="login-button bg-hyper-blue focus:bg-black focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 py-3 text-sm mt-6">
										Submit
									</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default ForgotPassword
