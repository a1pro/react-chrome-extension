import React, { useEffect, useState } from 'react'
import { useNavigate, Link, useLocation } from 'react-router-dom'
import Logo from '../../assets/logo.svg'
import Login from '../../assets/login-icon.svg'
import Signup from '../../assets/sign-up-icon.svg'
import { ReactComponent as SearchHeader } from '../../assets/search-header.svg'
import { ReactComponent as CrossButton } from '../../assets/cross-button.svg'

import './MainHeader.css'
import userState from '../../recoil/user'
import { useResetRecoilState, useRecoilValue } from 'recoil'

export const MainHeader = ({ isAuth, isShowEnterApp }) => {
	const [toggleNavBar, setToggleNavbar] = useState(false)
	const [rotate, setRotate] = useState(false)
	const [show, setShow] = useState(false)
	const user = useRecoilValue(userState)
	const resetUserState = useResetRecoilState(userState)
	const [isauth, setAuth] = useState(isAuth)
	const [toggleshow, settoggleShow] = useState(false)
	const [searchText, setSearchText] = useState('')
	const className = 'fixed'
	const scrollTrigger = 150

	const history = useNavigate()
	const location = useLocation()

	useEffect(() => {
		function onScroll() {
			const scrollPosition = window.scrollY
			if (
				window.scrollY >= scrollTrigger ||
				window.pageYOffset >= scrollTrigger
			) {
				document.getElementsByTagName('header')[0].classList.add(className)
			} else {
				document.getElementsByTagName('header')[0].classList.remove(className)
			}
		}

		window.addEventListener('scroll', onScroll)
		return () => {
			window.removeEventListener('scroll', onScroll)
		}
	}, [])

	const logout = (e) => {
		resetUserState()
		localStorage.removeItem('userInfo')
		history('/login')
	}
	useEffect(() => {
		setAuth(isAuth)
	}, [isAuth])

	const search = () => {
		// Regax to check if value is an ASIN
		if (
			!/\s/.test(searchText) &&
			searchText === searchText.toUpperCase() &&
			/\d/.test(searchText) &&
			searchText.length === 10
		) {
			history(`/product/${searchText}`)
		} else {
			history(`/product-hunter/${searchText}`)
		}
	}
	const getSearchText = (e) => {
		setSearchText(e.target.value)
	}
	return (
		<header
			className={`${toggleNavBar ? 'show' : ''}
			${isauth ? 'loggedin' : ''}
		${toggleshow ? 'show-getSearchText' : ''}`}
		>
			<div className="container">
				<div className="logo">
					<Link to="/">
						<img src={Logo} alt="logo" />
					</Link>
				</div>
				<div className="menu-right">
					<ul>
						{isShowEnterApp && (
							<>
								<li>
									<Link to="/">Home</Link>
								</li>
								<li>
									<a href="#">About us</a>
								</li>
								<li>
									<a href="#">Services</a>
								</li>
								<li>
									<Link to="/pricing">Pricing</Link>
								</li>
								<li>
									<Link to="/contact">Contact us</Link>
								</li>
							</>
						)}

						{!isauth &&
							location.pathname !== '/login' &&
							location.pathname !== `/register` && (
								<>
									<li>
										<Link to="/">Home</Link>
									</li>
									<li>
										<Link to="/pricing">Pricing</Link>
									</li>
									<li>
										<Link to="/contact">Contact us</Link>
									</li>
									<li className="hide-desktop">
										<Link className="no-underline" to="/login">
											Login
										</Link>
									</li>
									<li className="hide-desktop">
										<Link className="no-underline" to="/register">
											Sign up
										</Link>
									</li>
								</>
							)}
						{isauth && !isShowEnterApp && (
							<>
								<li>
									<Link to="/dashboard">Dashboard</Link>
								</li>
								<li>
									<Link to="/product-hunter">Product Hunter</Link>
								</li>
								<li>
									<Link to="/product/search">Product Details</Link>
								</li>
							</>
						)}
					</ul>

					{isShowEnterApp && (
						<Link to="/" className="no-underline enter-app-btn">
							Enter App
						</Link>
					)}
					{isauth && (
						<>
							<button onClick={logout}>Logout</button>
							{!isShowEnterApp && (
								<button
									className="seacrbtn"
									onClick={() => {
										settoggleShow(!toggleshow)
									}}
								>
									<SearchHeader />
								</button>
							)}
						</>
					)}
					{!isauth &&
						location.pathname !== '/login' &&
						location.pathname !== `/register` && (
							<>
								<Link to="/login" className="no-underline">
									<button className="login-btn">
										login <img src={Login} alt="icon" />
									</button>
								</Link>
								<Link to="/register" className="no-underline">
									<button className="signup-btn">
										Sign up
										<img src={Signup} alt="icon" />
									</button>
								</Link>
							</>
						)}
				</div>
				<button
					onClick={() => setToggleNavbar(!toggleNavBar)}
					className="hamberger-btn"
				>
					<span></span>
				</button>
			</div>
			{toggleshow && (
				<div className="search-wrap">
					<div className="container">
						<div className="search-bar flex items-center">
							<input
								aria-label="Search Bar"
								className="focus:outline-none placeholder-gray-500 form-control"
								type="text"
								placeholder="Search Keyword, ASIN, GTIN, or UPC"
								onChange={getSearchText}
							/>
							<button
								onClick={search}
								className="cursor-pointer search-submit-btn"
							>
								<SearchHeader />
							</button>
							<button
								className="cursor-pointer close-search"
								onClick={() => {
									settoggleShow(!toggleshow)
								}}
							>
								<CrossButton />
							</button>
						</div>
					</div>
				</div>
			)}
		</header>
	)
}

export default MainHeader
