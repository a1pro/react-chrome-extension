import React, { useEffect, useRef, useState } from 'react'
import logo from '../../assets/logo.png'
import Loader from '../Loader/Loader'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
import ErrorMessage from '../ErrorMessage/ErrorMessage'
import './Login.css'
import { useSetRecoilState } from 'recoil'
import userState from '../../recoil/user'
import { useForm } from 'react-hook-form'
const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

const Login = () => {
	const setUser = useSetRecoilState(userState)
	const [loading, setLoading] = useState(false)
	const [email, setEmail] = useState('')
	const [error, setError] = useState('')
	const history = useNavigate()
	const { register, handleSubmit } = useForm()

	useEffect(() => {
		const token = localStorage.getItem('userInfo')
			? JSON.parse(localStorage.getItem('userInfo'))
			: null
		if (token) {
			history('/')
		}
		if (localStorage.getItem('email')) {
			setEmail(localStorage.getItem('email'))
		}
	}, [history])

	const onSubmit = async ({ email, password, rememberMe }) => {
		// data.preventDefault()
		if (rememberMe) {
			localStorage.setItem('email', email)
		} else {
			localStorage.removeItem('email')
		}
		setLoading(true)
		axios
			.post(`${HYPER_API_BASE_URL}/api/auth/signin`, {
				email,
				password,
			})
			.then((userData) => {
				const data = userData.data
				localStorage.setItem('userInfo', JSON.stringify(userData))
				setUser({ ...userState, userData })
				setUser((s) => {
					return { ...s, ...data }
				})
				setLoading(false)
				history('/dashboard')
			})
			.catch((err) => {
				console.error(`Code: ${err.code}\nMessage: ${err.message}`)
				const errMessage =
					err.response && err.response.data.message
						? err.response.data.message
						: err.message
				setLoading(false)
				setError(errMessage)
				history('/')
			})
			.finally(() => setLoading(false))
	}

	return (
		<>
			{loading && <Loader margins="mr-0">Logging In...</Loader>}
			<div className="login-container bg-gray-50 pt-32 pb-8">
				<div className="flex align-items-center justify-center mb-8 w-100">
					<div className="login max-w-2xl w-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
						<div className="max-w-2xl w-full space-y-8">
							<div>
								<img
									className="mx-auto"
									src={logo}
									alt="Workflow"
									width={150}
								/>
							</div>
							{error && <ErrorMessage>{error}</ErrorMessage>}
							<div className="mx-auto flex justify-center lg:items-center h-full">
								<form
									onSubmit={handleSubmit(onSubmit)}
									className="px-2 sm:px-0"
									action="#"
									method="POST"
								>
									<div className="w-96 px-2 flex flex-col items-center justify-center">
										<h3 className="text-2xl sm:text-3xl xl:text-2xl font-semibold leading-tight">
											Log In
										</h3>
									</div>
									<div className="mt-8 w-full rounded-md shadow-sm -space-y-px ">
										<div>
											<label htmlFor="email-address" className="sr-only">
												Email address
											</label>
											<input
												id="email-address"
												name="email"
												type="email"
												{...register('email')}
												autoComplete="email"
												required
												className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Email address"
												// value={email}
											/>
										</div>
										<div>
											<label htmlFor="password" className="sr-only">
												Password
											</label>
											<input
												id="password"
												name="password"
												type="password"
												{...register('password')}
												autoComplete="current-password"
												required
												className="mt-3 rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Password"
											/>
										</div>
									</div>
									<div className="pt-6 w-full flex justify-between px-2 sm:px-6">
										{/* TODO: add actions for remember me and forgot password */}
										<div className="flex items-center">
											<input
												id="rememberme"
												{...register('rememberMe')}
												className="w-3 h-3 mr-2"
												type="checkbox"
											/>
											<label htmlFor="rememberme" className="text-xs">
												Remember Me
											</label>
										</div>
										<Link className="text-xs" to="/forgot-password">
											Forgot Password?
										</Link>
									</div>
									<div className="px-2 sm:px-6">
										<button className="login-button bg-hyper-blue focus:bg-black focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 py-3 text-sm mt-6">
											Log In
										</button>
										<div className="flex justify-center">
											<p className="mt-10 mr-1 text-xs text-center text-black-400">
												Don’t have an account?{' '}
											</p>
											<Link
												className="mt-10 text-xs text-center text-black-400"
												to="/register"
											>
												<span className="underline">Sign Up</span>
											</Link>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Login
