import { React, useState } from 'react'
import './RelatedItems.css'
const RelatedItems = (props) => {
	return (
		<div>
			<div className="w-11/12 m-auto py-6 text-center xl:w-10/12">
				<h4 className="mb-12">Products related to this item</h4>
				<div className="items-holder">
					{props.relatedItem.map((el) => {
						return (
							<div
								className="related-items-container flex flex-col items-center justify-between m-auto cursor-pointer h-full"
								key={Math.random()}
							>
								<div className="related-items-imgs w-full h-3/6 flex items-center justify-center cursor-pointer px-5">
									<img src={Object.values(el.images)[0].link} alt="" />
								</div>
								<div className="rate-price mt-5 w-full h-3/6">
									<a
										className="font-bold no-underline text-base text-zinc-800"
										href={`/product-info/${el.asin}`}
									>
										{el.name}
									</a>
									<div className="related-item-rating flex justify-start items-center">
										<div
											className={`rating rating-lg rating-half rating-number-${
												Math.round(el.rating) * 2
											}`}
										>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="2"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="4"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="6"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="8"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="10"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
										</div>
										<a
											className="ml-2.5 mt-1 no-underline font-medium text-blue-500"
											href={`https://www.amazon.com/product-reviews/${el.asin}`}
										>
											{el.ratingsTotal}
										</a>
									</div>
									<div className="flex items-center">
										<h2 className="m-0 font-bold text-zinc-600">{el.price}</h2>
									</div>
								</div>
							</div>
						)
					})}
				</div>
			</div>
		</div>
	)
}
export default RelatedItems
