import React from 'react'
import FormControl from '@mui/material/FormControl'
import { Link } from 'react-router-dom'
import './ProfitCalculator.css'

const ProfitCalculator = ({ props }) => {
	return (
		<div className="profit-calculator my-3">
			<FormControl className="">
				<h4>
					<strong>FBA Profit Calculator</strong>
				</h4>
				<div className="row mb-4">
					<div className="col-2 text-center ">
						<Link to="#">
							<img
								src={props.itemImgs[0]}
								className="object-contain border border-1"
							/>
						</Link>
					</div>
					<div className="col-10">
						<p className="">{props.searchData.name}</p>
					</div>
				</div>
				<div className="row">
					<div className="col-sm-6 col-12">
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label w-200">Product Weight:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									name="product weight"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Product Weight"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Product Dimensions:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									value={props.searchData.dimensions}
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Product Tier:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Product Tier"
									required
								/>
							</div>
						</div>

						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Product Price:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Product Price"
									value={props.searchData.price}
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">FBA Fulfillment Fee:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="FBA Fulfillment Fee"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Referral Fee:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Referral Fee"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Variable Closing Fees:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Variable Closing Fees"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Total FBA Fee:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Total FBA Fee"
									required
								/>
							</div>
						</div>
					</div>
					<div className="col-sm-6 col-12 position-relative">
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Net:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Net"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Product Cost:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Product Cost"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">ROI Percentage:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="ROI Percentage"
									required
								/>
							</div>
						</div>
						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Shipping cost:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Shipping cost "
									required
								/>
							</div>
						</div>

						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Labeling cost:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Labeling cost "
									required
								/>
							</div>
						</div>

						<div className="col mb-3">
							<div className="col-auto d-none">
								<label className="col-form-label">Prep cost:</label>
							</div>
							<div className="col-auto text-end">
								<input
									type="text"
									className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
									placeholder="Prep cost"
									required
								/>
							</div>
						</div>

						<div className="row mb-2 justify-content-between">
							<div className="col-auto">Profit</div>
							<div className="col-auto text-end">
								<strong>$ 40.50</strong>
							</div>
						</div>
						<div className="border mb-2"></div>

						<div className="d-flex justify-content-end bottom-0 end-0 mb-3">
							<button
								className="bg-hyper-blue hover:opacity-80 w-52 justify-end font-semibold focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 py-3 text-sm"
								type="submit"
							>
								Calculate Profit
							</button>
						</div>
					</div>
				</div>
			</FormControl>
		</div>
	)
}
export default ProfitCalculator
