import React from 'react'

const SuccessMessage = ({ children }) => {
	return (
		<div className="flex justify-content-center mt-3">
			<div
				className="bg-blue-100 border border-blue-100 text-blue-100 px-4 py-3 rounded relative"
				role="alert"
			>
				<span className="block sm:inline text-black">{children}</span>
				<span className="absolute top-0 bottom-0 right-0 px-4 py-3">
					<svg
						className="fill-current h-3 w-6 text-red-500"
						role="button"
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 20 20"
					></svg>
				</span>
			</div>
		</div>
	)
}

export default SuccessMessage
