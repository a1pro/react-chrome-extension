import { React, useLayoutEffect, useState } from 'react'
import SupplierImg from '../../assets/supplier_img.png'
import ChartImg from '../../assets/chart_img.png'
import InfoImg from '../../assets/info_img.png'
import ReactSpeedometer from 'react-d3-speedometer'
import { Line, Pie } from 'react-chartjs-2'
import ChartDataLabels from 'chartjs-plugin-datalabels'
import './StatisticsInfo.css'
import ProfitCalculator from '../ProfitCalculator/ProfitCalculator'
import {
	Chart as Chartjs,
	Title,
	Legend,
	ArcElement,
	Filler,
	Tooltip,
	PointElement,
	LineElement,
	PieController,
	LinearScale,
	CategoryScale,
} from 'chart.js'
Chartjs.register(
	Title,
	Legend,
	ArcElement,
	Filler,
	Tooltip,
	PointElement,
	LineElement,
	PieController,
	LinearScale,
	CategoryScale,
	ChartDataLabels
)
const chartjsData = require('../../mocks/MockChartjsData.json')
function useWindowSize() {
	const [size, setSize] = useState([0, 0])
	useLayoutEffect(() => {
		function updateSize() {
			setSize([window.innerWidth])
		}
		window.addEventListener('resize', updateSize)
		updateSize()
		return () => window.removeEventListener('resize', updateSize)
	}, [])
	return size
}
const StatisticsInfo = (props) => {
	const [width] = useWindowSize()

	const pieOptions = {
		responsive: true,
		maintainAspectRatio: true,
		tooltips: {
			enabled: false,
		},
		plugins: {
			legend: {
				position: 'top',
				labels: {
					usePointStyle: true,
					padding: 5,
					font: {
						weight: 500,
						size: 12,
						family: "'Montserrat', 'sans-serif'",
					},
				},
			},
			datalabels: {
				display: true,
				borderRadius: 3,
				font: {
					weight: 500,
					size: 14,
				},
				color: ['#595959', '#ffffff'],
				formatter: (value) => {
					return '$' + (Math.round(value * 100) / 100).toFixed(2)
				},
			},
		},
	}

	const lineProfileOptions = {
		scales: {
			y: {
				min: 20,
				max: 100,
				ticks: {
					stepSize: 20,
					callback: function (value) {
						return ((value / 100) * 100).toFixed(0) + '%'
					},
					font: {
						family: "'Montserrat', 'sans-serif'",
						weight: 700,
					},
				},
				scaleLabel: {
					display: true,
					labelString: 'Percentage',
				},
			},
		},
		tooltips: {
			enabled: false,
		},
		plugins: {
			legend: {
				display: false,
			},
			datalabels: {
				font: {
					size: 0,
				},
			},
		},
	}
	return (
		<div className="statistics-container w-11/12 flex flex-col justify-between items-start m-auto py-6 lg:w-10/12 lg:flex-row-reverse">
			<div className="statistics-container-right flex flex-col w-full lg:w-6/12">
				<div className="info-container">
					<div className="info-holder">
						<h4>ASIN</h4>
						<div className="info-handler">
							<p>-</p>
							<h4>{props.searchData.asin}</h4>
						</div>
					</div>
				</div>
				<div className="info-container">
					<div className="info-holder">
						<h4>Amazon Link</h4>
						<div className="info-handler">
							<p>-</p>
							<a href={`https://amazon.com/dp/${props.searchData.asin}`}>
								Amazon.com
							</a>
						</div>
					</div>
				</div>
				<div className="info-container">
					<div className="rish-sales relative flex justify-between items-center">
						<div
							style={{
								width: '100%',
								minWidth: '240px',
								height: 'auto',
								borderRight: '1px solid #DEDEDE',
							}}
						>
							<div className="statistics-monthly relative text-base font-bold m-0 mt-5 w-fit text-zinc-600">
								<p>Sales Estimate</p>
								<span>200</span>
								<span>Monthly</span>
							</div>
							<p className="font-bold absolute text-base text-cyan-400">
								Sales
							</p>
							<Line
								style={{ maxHeight: '170px' }}
								data={chartjsData.lineSalesData}
								options={chartjsData.lineSalesOptions}
							/>
						</div>
						<div
							className="risk-score flex flex-col justify-center items-center"
							style={{ height: '200px' }}
						>
							<p>Risk Score</p>
							<ReactSpeedometer
								width={200}
								height={'100%'}
								labelFontSize={'11px'}
								needleHeightRatio={0.7}
								maxValue={10}
								value={10 - 9}
								currentValueText={'9'}
								needleColor={'black'}
								customSegmentLabels={[
									{
										text: 'HIGH',
										position: 'OUTSIDE',
										color: '#555',
									},
									{
										position: 'INSIDE',
										color: '#555',
									},
									{
										text: 'MEDIUM',
										position: 'OUTSIDE',
										color: '#555',
									},
									{
										position: 'INSIDE',
										color: '#555',
									},
									{
										text: 'LOW',
										position: 'OUTSIDE',
										color: '#555',
									},
								]}
								ringWidth={42}
								needleTransitionDuration={3333}
								needleTransition="easeElastic"
								textColor={'#d8dee9'}
							/>
						</div>
					</div>
					<div className="opportunity-score-container flex flex-col items-center">
						<p>Opportunity Score</p>
						<div className="opportunity-score flex justify-center items-center">
							<p>4</p>
							<div className="flex flex-col justify-center items-center ml-2.5">
								<h3 className="text-lg font-bold m-0 text-cyan-400">
									High Demand
								</h3>
								<p className="m-0">with high Comp.</p>
							</div>
						</div>
						<ReactSpeedometer
							width={250}
							height={'100%'}
							labelFontSize={'11px'}
							needleHeightRatio={0.7}
							maxValue={10}
							value={10 - 4}
							currentValueText={'4'}
							needleColor={'black'}
							ringWidth={20}
							needleTransitionDuration={3333}
							needleTransition="easeElastic"
							textColor={'#d8dee9'}
							maxSegmentLabels={0}
							startColor={'#f97655'}
							endColor={'#62fc95'}
						/>
					</div>
					<div className="info-container">
						<div className="info-holder ax-2">
							<h4>Supplier Price Estimate</h4>
							<div className="info-handler ax-2">
								<p>-</p>
								<h4>$10K</h4>
							</div>
						</div>
					</div>
					<div className="info-container">
						<div className="info-holder ax-2">
							<h4>Category</h4>
							<div className="info-handler ax-2" style={{ width: '100%' }}>
								<p>-</p>
								<a
									href={
										props?.searchData?.bestSellersRank
											? props?.searchData?.bestSellersRank?.length > 0
												? Object.values(props?.searchData?.bestSellersRank)[0]
														?.link
												: 'https://www.amazon.com/'
											: 'https://www.amazon.com/'
									}
								>
									{props?.searchData?.bestSellersRank
										? Object.values(props?.searchData?.bestSellersRank)[0]
												.category
										: 'Category not found'}
								</a>
							</div>
						</div>
					</div>
					<div className="info-container">
						<div className="info-holder ax-2">
							<img
								src={SupplierImg}
								alt=""
								width={166}
								style={{ margin: '0.875rem 0rem' }}
							/>
							<div className="info-handler ax-2">
								<p>-</p>
								<a href="https://www.amazon.com">Contact Supplier</a>
							</div>
						</div>
					</div>
					<div className="info-container">
						<div className="info-holder ax-2">
							<h4>Sales Rank</h4>
							<div
								className="info-handler ax-2"
								style={{ width: '70%', justifyContent: 'space-between' }}
							>
								<p>-</p>
								<a
									href={
										props.searchData?.bestSellersRank
											? Object.values(props.searchData.bestSellersRank)[0].link
											: 'https://www.amazon.com/'
									}
								>
									{props.searchData?.bestSellersRank
										? `#
										  ${Object.values(props.searchData.bestSellersRank)[0].rank}
										  in										  ${
												Object.values(props.searchData.bestSellersRank)[0]
													.category
											}(See Top 100 in ${
												Object.values(props.searchData.bestSellersRank)[0]
													.category
										  })`
										: 'Not Found'}
								</a>
							</div>
						</div>
					</div>
					<div className="info-container">
						<div className="info-holder ax-2">
							<h4>Product Rating</h4>
							<div className="info rating-info">
								<div className="info-handler ax-2" style={{ width: 'auto' }}>
									<p>-</p>
									<div>
										<div
											className={`rating rating-lg rating-half rating-number-${
												Math.round(props.searchData.rating) * 2
											}`}
										>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="2"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="4"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="6"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="8"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
											<input
												type="radio"
												name="rating-10"
												className="bg-green-500 mask mask-star-2 mask-half-1"
											/>
											<input
												type="radio"
												name="rating-10"
												place="10"
												className="bg-green-500 mask mask-star-2 mask-half-2"
											/>
										</div>
										<h6 style={{ margin: '0rem' }}>
											{props.searchData.rating}{' '}
											{width > 500 ? 'out of 5 stars' : ' / 5 star'}
										</h6>
									</div>
								</div>
								<a
									href={`https://www.amazon.com/product-reviews/${props.searchData.asin}`}
								>
									{props.searchData?.ratingsTotal
										? props.searchData.ratingsTotal + 'ratings'
										: 'Not Found'}
								</a>
							</div>
						</div>
					</div>
					<div
						className="info-container"
						style={{ borderBottom: '1px solid #DEDEDE' }}
					>
						<div className="info-holder ax-2">
							<h4>Total Reviews</h4>
							<div className="info">
								<div className="info-handler ax-2">
									<p>-</p>
									<h4>
										{props.searchData?.topReviews
											? Object.values(props.searchData.topReviews).length
											: 'Not Found'}
									</h4>
								</div>
								<a
									href={`https://www.amazon.com/product-reviews/${props.searchData.asin}`}
								>
									{props.searchData?.topReviews
										? Object.values(props.searchData.topReviews).length
										: 'Not Found'}
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="statistics-container-left">
				<div className="flex flex-col flex-wrap justify-center items-center md:flex-nowrap sm:flex-row">
					<div className="statistics-data">
						<div className="statistics-text">
							<p>Average Price</p>
							<p>$59.00</p>
						</div>
						<div className="statistics-data-charts">
							<p>8.9%</p>
							<img src={ChartImg} alt="" />
						</div>
					</div>
					<div className="statistics-data">
						<div className="statistics-text">
							<p>Monthly Sales</p>
							<p>200</p>
						</div>
						<div className="statistics-data-charts">
							<p>8.9%</p>
							<img src={ChartImg} alt="" />
						</div>
					</div>
					<div className="statistics-data" style={{ borderRight: 'none' }}>
						<div className="statistics-text">
							<p>Monthly Revenue</p>
							<p>$59.00</p>
						</div>
						<div className="statistics-data-charts">
							<p>8.9%</p>
							<img src={ChartImg} alt="" />
						</div>
					</div>
				</div>
				<div className="flex flex-col flex-wrap justify-center items-center md:flex-nowrap sm:flex-row">
					<div
						className="statistics-data"
						style={{ borderTop: 'none', width: '35%', height: '181px' }}
					>
						<div
							className="statistics-text"
							style={{ textAlign: 'center', width: '100%' }}
						>
							<p>FBA fees</p>
						</div>
					</div>
					<div
						className="statistics-data"
						style={{ borderRight: 'none', borderTop: 'none', width: '65%' }}
					>
						<div
							className="statistics-text"
							style={{ width: '100%', height: '100%' }}
						>
							<Pie
								style={{ maxWidth: '100%', maxHeight: '150px' }}
								data={chartjsData.pieData}
								options={pieOptions}
							/>
						</div>
					</div>
				</div>
				<div>
					<div className="flex justify-between items-center py-7 text-zinc-600">
						<div className="estimated-text">
							<p>Estimated Profit</p>
							<h2>$50,000</h2>
						</div>
						<div className="estimated-img">
							<p>Monthly Data</p>
							<img src={InfoImg} alt="InfoImg" />
						</div>
					</div>
					<Line
						data={chartjsData.lineProfiteData}
						options={lineProfileOptions}
					/>
				</div>
				<ProfitCalculator props={props} />
			</div>
		</div>
	)
}
export default StatisticsInfo
