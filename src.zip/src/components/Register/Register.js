import React, { useEffect, useRef, useState } from 'react'
import Logo from '../../assets/logo.png'
import { ReactComponent as GreenCheckCircleSvg } from '../../assets/green-checkmark-circle.svg'
import { ReactComponent as RedXCircleSvg } from '../../assets/red-x-circle.svg'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import axios from 'axios'
import ErrorMessage from '../ErrorMessage/ErrorMessage'
import Loader from '../Loader/Loader'
import './Register.css'
import { usePasswordValidation } from '../../utils/hooks/usePasswordValidation'
import { createPaymentIntent } from '../../utils/stripe/paymentIntent'
import { useForm } from 'react-hook-form'
import { useSetRecoilState } from 'recoil'
import userState from '../../recoil/user'

const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

const Register = () => {
	const { search } = useLocation()
	const setUser = useSetRecoilState(userState)
	const [loading, setLoading] = useState(false)
	const [purchaseIntent, setPurchaseIntent] = useState(false)
	const [type, setType] = useState(null)
	const [firstName, setFirstName] = useState('')
	const [lastName, setLastName] = useState('')
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState({
		firstPassword: '',
		secondPassword: '',
	})
	const [error, setError] = useState('')
	const history = useNavigate()
	const { register, handleSubmit } = useForm()

	useEffect(() => {
		const query = new URLSearchParams(search)
		const Plan = query.get('buyPlan')
		const Type = query.get('type')
		setPurchaseIntent(Plan)
		setType(Type)
		const token = localStorage.getItem('userInfo')
			? JSON.parse(localStorage.getItem('userInfo'))
			: null
		if (token) {
			history('/')
		}
	}, [history])

	const onSubmit = async ({ email, rememberMe }) => {
		if (rememberMe) {
			localStorage.setItem('email', email)
		} else {
			localStorage.removeItem('email')
		}
		if (passwordIsValid()) {
			setLoading(true)
			axios
				.post(`${HYPER_API_BASE_URL}/api/auth/signup`, {
					firstName,
					lastName,
					email,
					password: password.firstPassword,
				})
				.then((data) => {
					const userData = data.data
					localStorage.setItem('userInfo', JSON.stringify(data))
					setUser({ ...userState, data })
					setUser((s) => {
						return { ...s, ...userData }
					})
					setLoading(false)
					if (purchaseIntent) {
						createPaymentIntent(type)
					} else {
						history('/dashboard')
					}
				})
				.catch((err) => {
					console.error(`Code: ${err.code}\nMessage: ${err.message}`)
					const errMessage =
						err.response && err.response.data.message
							? err.response.data.message
							: err.message
					setLoading(false)
					setError(errMessage)
					history('/')
				})
				.finally(() => setLoading(false))
		}
	}

	const [validLength, hasNumber, upperCase, lowerCase, match, specialChar] =
		usePasswordValidation({
			firstPassword: password.firstPassword,
			secondPassword: password.secondPassword,
		})

	const passwordIsValid = () => {
		if (
			validLength &&
			hasNumber &&
			upperCase &&
			lowerCase &&
			match &&
			specialChar
		) {
			return true
		}
		return false
	}

	/* Setting first and second password values so they can be compared on submit */
	const setFirst = (value) => setPassword({ ...password, firstPassword: value })

	const setSecond = (value) =>
		setPassword({ ...password, secondPassword: value })

	return (
		<>
			{loading && <Loader margins="mr-0">Registering...</Loader>}
			<div className="register-container bg-gray-50 pt-32 pb-8">
				<div className="flex align-items-center justify-center mb-8 w-100">
					<div className="register max-w-2xl w-full flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
						<div className="max-w-2xl w-full space-y-8">
							<div>
								<img
									className="mx-auto"
									src={Logo}
									alt="Workflow"
									width={150}
								/>
							</div>
							{error && <ErrorMessage>{error}</ErrorMessage>}
							<div className="mx-auto mt-4 flex justify-center lg:items-center h-full">
								<form
									onSubmit={handleSubmit(onSubmit)}
									className="px-2 sm:px-0"
									action="#"
									method="POST"
								>
									<div className="w-96 px-2 flex flex-col items-center justify-center">
										<h3 className="text-2xl sm:text-3xl xl:text-2xl font-semibold leading-tight">
											Sign Up
										</h3>
									</div>
									<div className="mt-4 w-full rounded-md shadow-sm -space-y-px ">
										<div>
											<label htmlFor="first-name" className="sr-only">
												First name
											</label>
											<input
												id="first-name"
												name="firstName"
												type="text"
												autoComplete="firstName"
												required
												className="rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="First name"
												value={firstName}
												onChange={(e) => setFirstName(e.target.value)}
											/>
										</div>
										<div>
											<label htmlFor="last-name" className="sr-only">
												Last name
											</label>
											<input
												id="last-name"
												name="lastName"
												type="text"
												autoComplete="lastName"
												required
												className="mt-3 rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Last name"
												value={lastName}
												onChange={(e) => setLastName(e.target.value)}
											/>
										</div>
										<div>
											<label htmlFor="email-address" className="sr-only">
												Email address
											</label>
											<input
												id="email-address"
												name="email"
												type="email"
												{...register('email')}
												autoComplete="email"
												required
												className="mt-3 rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900  focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Email address"
											/>
										</div>
										<div>
											<label htmlFor="password" className="sr-only">
												Password
											</label>
											<input
												id="password"
												name="password"
												type="password"
												autoComplete="current-password"
												required
												className="mt-3 rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Password"
												value={password.firstPassword}
												onChange={(e) => setFirst(e.target.value)}
											/>
										</div>
										<div>
											<label htmlFor="password" className="sr-only">
												Re-enter Password
											</label>
											<input
												id="second-password"
												name="second-password"
												type="password"
												autoComplete="current-password"
												required
												className="mt-3 rounded-none transition duration-150 ease-in-out w-full px-3 py-2 border-2 border-gray-300 placeholder-gray-500 text-gray-900 rounded-b-md focus:outline-none focus:border-hyper-blue focus:z-10 sm:text-sm"
												placeholder="Re-enter Password"
												value={password.secondPassword}
												onChange={(e) => setSecond(e.target.value)}
											/>
										</div>
									</div>

									<div className="flex justify-start mt-3 p-1">
										<ul className="pl-0">
											<li className="flex items-center py-1">
												{password.firstPassword === password.secondPassword &&
												password.firstPassword.length > 0 ? (
													<>
														<GreenCheckCircleSvg />
														<span className="font-medium text-sm ml-3 text-green-700">
															Passwords match
														</span>
													</>
												) : (
													<>
														<RedXCircleSvg />
														<div className="font-medium text-sm ml-3 text-red-700">
															Passwords match
														</div>
													</>
												)}
											</li>
											<li className="flex items-center pt-1">
												{password.firstPassword.length > 7 ? (
													<>
														<GreenCheckCircleSvg />
														<span className="text-green-700 font-medium text-sm ml-3 ">
															At least 8 characters required
														</span>
													</>
												) : (
													<>
														<RedXCircleSvg />
														<span className="text-red-700 font-medium text-sm ml-3">
															At least 8 characters required
														</span>
													</>
												)}
											</li>
										</ul>
									</div>

									<div className="w-full flex justify-between px-2 sm:px-6">
										{/* TODO: add actions for remember me */}
										<div className="flex items-center">
											<input
												id="rememberme"
												{...register('rememberMe')}
												className="w-3 h-3 mr-2"
												type="checkbox"
											/>
											<label htmlFor="rememberme" className="text-xs">
												Remember Me
											</label>
										</div>
										<div className="flex items-center">
											<Link to="/login">
												<p className="mb-0 text-xs text-center text-black underline">
													Already have an account?
												</p>
											</Link>
										</div>
									</div>
									<div className="px-2 sm:px-6">
										<button className="register-button bg-hyper-blue focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 text-sm mt-6">
											Register
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Register
