import React, { useState, useEffect } from 'react'
import { ReactComponent as BullseyeSvg } from '../../assets/bullseye.svg'
import { ReactComponent as DashboardSvg } from '../../assets/dashboard.svg'
import { ReactComponent as FingerprintSvg } from '../../assets/fingerprint.svg'
import { useNavigate } from 'react-router-dom'
import './LeftNavigation.css'
import { useRecoilValue } from 'recoil'
import userState from '../../recoil/user'

const LeftNavigation = ({ isAuth }) => {
	const history = useNavigate()
	const user = useRecoilValue(userState)
	const [show, setShow] = useState(false)
	const [tooltipStatus, setTooltipStatus] = useState(0)

	return (
		<>
			<div className="hide-mobile">
				{isAuth && (
					<div className="left-nav-container flex flex-no-wrap h-full">
						<div className="left-nav h-full bg-gray-900">
							<div className="flex w-full h-full">
								<div className="flex flex-col h-full justify-between">
									<div>
										<div className="flex items-center relative">
											<div className="-mt-5" onClick={() => setShow(!show)}>
												{show ? (
													<button
														aria-label="minimize sidebar"
														id="close"
														className="expand-collapse-button w-6 h-6 right-0 absolute shadow rounded-full flex items-center justify-center cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-600"
													>
														<svg
															width={16}
															height={16}
															viewBox="0 0 16 16"
															fill="none"
															xmlns="http://www.w3.org/2000/svg"
														>
															<path
																d="M10 4L6 8L10 12"
																stroke="white"
																strokeWidth="1.25"
																strokeLinecap="round"
																strokeLinejoin="round"
															/>
														</svg>
													</button>
												) : (
													<button
														id="open"
														className="expand-collapse-button w-6 h-6 right-0 absolute shadow rounded-full flex items-center justify-center cursor-pointer focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-600"
													>
														<svg
															aria-label="expand sidebar"
															width={16}
															height={16}
															viewBox="0 0 16 16"
															fill="none"
															xmlns="http://www.w3.org/2000/svg"
														>
															<path
																d="M6 12L10 8L6 4"
																stroke="white"
																strokeWidth="1.25"
																strokeLinecap="round"
																strokeLinejoin="round"
															/>
														</svg>
													</button>
												)}
											</div>
										</div>
										<div className="flex items-center">
											<ul aria-orientation="vertical" className="list-item">
												<li
													tabIndex={0}
													role="button"
													aria-label="dashboard"
													className="cursor-pointer mt-4"
													onClick={() => history('/dashboard')}
												>
													<div className="flex ">
														<DashboardSvg className="svg" />
														{show && (
															<div className="w-full align-self-center">
																<p className="whitespace-nowrap text-base pl-2 cursor-pointer text-gray-400">
																	Dashboard
																</p>
															</div>
														)}
													</div>
												</li>
												<li
													tabIndex={0}
													role="button"
													aria-label="Product Hunter"
													className="cursor-pointer mt-4"
													onClick={() => history('/product-hunter')}
												>
													<div className="flex ">
														<BullseyeSvg className="svg" />
														{show && (
															<div className="w-full align-self-center">
																<p className="whitespace-nowrap text-base pl-2 cursor-pointer text-gray-400">
																	Product Hunter
																</p>
															</div>
														)}
													</div>
												</li>
												<li
													tabIndex={0}
													role="button"
													aria-label="Product Details"
													className="cursor-pointer mt-4"
													onClick={() => history('/product/search')}
												>
													<div className="flex ">
														<FingerprintSvg className="svg" />
														{show && (
															<div className="w-full align-self-center">
																<p className="whitespace-nowrap text-base pl-2 cursor-pointer text-gray-400">
																	Product Details
																</p>
															</div>
														)}
													</div>
												</li>
												{/* <li
											tabIndex={0}
											role="button"
											aria-label="Tracking"
											className="cursor-pointer mt-4"
											// TODO: populate with value route
											onClick={() => history('/')}
										>
											<div className="flex ">
												<TruckSvg className="svg" />
												{show && (
													<div className="w-full align-self-center">
														<p className="whitespace-nowrap text-base leading-4 pl-2 cursor-pointer text-gray-400">
															Tracking
														</p>
													</div>
												)}
											</div>
										</li>
										<li
											tabIndex={0}
											role="button"
											aria-label="Order Automation"
											className="cursor-pointer mt-4"
											// TODO: populate with value route
											onClick={() => history('/')}
										>
											<div className="flex ">
												<RefreshSvg className="svg" />
												{show && (
													<div className="w-full align-self-center">
														<p className="whitespace-nowrap text-base leading-4 pl-2 cursor-pointer text-gray-400">
															Order Automation
														</p>
													</div>
												)}
											</div>
										</li> */}
											</ul>

											{/* Text for left navigation items when it is open */}
											{/* {show && (
										<div className="w-full mt-10">
											<p className="list-item-text text-base leading-4 pl-3 cursor-pointer text-gray-400">
												Dashboard
											</p>
										</div>
									)} */}
										</div>
									</div>
									<div
										className="flex items-center justify-between relative"
										id="profile"
									>
										{show ? (
											<>
												<div className="flex items-center">
													<img
														src="https://i.ibb.co/fDyfmVz/pic.png"
														alt="profile picture"
														className="w-7 h-7 rounded-full"
													/>
													<p className="text-base leading-4 pl-3 text-gray-100 mb-0">
														{`${user.firstName} ${user.lastName}`}
													</p>
												</div>

												<div
													onMouseEnter={() => setTooltipStatus(1)}
													onMouseLeave={() => setTooltipStatus(0)}
												>
													<svg
														width={16}
														height={16}
														viewBox="0 0 16 16"
														fill="none"
														xmlns="http://www.w3.org/2000/svg"
													>
														<path
															d="M8.00016 14.6666C4.31816 14.6666 1.3335 11.682 1.3335 7.99998C1.3335 4.31798 4.31816 1.33331 8.00016 1.33331C11.6822 1.33331 14.6668 4.31798 14.6668 7.99998C14.6668 11.682 11.6822 14.6666 8.00016 14.6666ZM7.3335 7.33331V11.3333H8.66683V7.33331H7.3335ZM7.3335 4.66665V5.99998H8.66683V4.66665H7.3335Z"
															fill="white"
														/>
													</svg>
												</div>
												{tooltipStatus === 1 && (
													<div
														role="tooltip"
														className="z-20 md:w-52 top-0 md:-mt-2 -mt-8 absolute transition duration-150 ease-in-out  ml-8 shadow bg-white p-4 rounded opacity-0"
													>
														<svg
															className="absolute left-0 -ml-2 -mt-1.5 bottom-0 top-0 h-full"
															width="9px"
															height="16px"
															viewBox="0 0 9 16"
															version="1.1"
															xmlns="http://www.w3.org/2000/svg"
															xmlnsXlink="http://www.w3.org/1999/xlink"
														>
															<g
																id="Page-1"
																stroke="none"
																strokeWidth={1}
																fill="none"
																fillRule="evenodd"
															>
																<g
																	id="Tooltips-"
																	transform="translate(-874.000000, -1029.000000)"
																	fill="#FFFFFF"
																>
																	<g
																		id="Group-3-Copy-16"
																		transform="translate(850.000000, 975.000000)"
																	>
																		<g
																			id="Group-2"
																			transform="translate(24.000000, 0.000000)"
																		>
																			<polygon
																				id="Triangle"
																				transform="translate(4.500000, 62.000000) rotate(-90.000000) translate(-4.500000, -62.000000) "
																				points="4.5 57.5 12.5 66.5 -3.5 66.5"
																			/>
																		</g>
																	</g>
																</g>
															</g>
														</svg>
														<p className="text-sm font-bold text-gray-800 pb-1">
															Profile Picture and name
														</p>
													</div>
												)}
											</>
										) : (
											<div className="flex items-center justify-between ">
												<img
													src="https://i.ibb.co/fDyfmVz/pic.png"
													alt="profile picture"
													className="w-7 h-7 rounded-full"
												/>
											</div>
										)}
									</div>
								</div>
							</div>
						</div>
						<div className="w-full" />
					</div>
				)}
			</div>
		</>
	)
}

export default LeftNavigation
