import React, { useEffect, useState } from 'react'
import axios from 'axios'
import FormControl from '@mui/material/FormControl'
import Button from '@mui/material/Button'
import { useForm } from 'react-hook-form'
import { useRecoilValue, useSetRecoilState } from 'recoil'
import userState from '../../recoil/user'
import ErrorMessage from '../ErrorMessage/ErrorMessage'

const HYPER_API_BASE_URL =
	process.env.HYPER_API_BASE_URL || 'https://hyper-api-proto.herokuapp.com'

const AccountPersonalInfoSettings = () => {
	const user = useRecoilValue(userState)
	const setUser = useSetRecoilState(userState)
	const { register, handleSubmit, reset, watch } = useForm({
		defaultValues: {
			firstName: user.firstName,
			lastName: user.lastName,
			email: user.email,
		},
	})
	const [loading, setLoading] = useState(false)
	const [error, setError] = useState('')

	const onSubmit = (data) => {
		if (
			data.firstName.length === 0 ||
			data.lastName.length === 0 ||
			data.email.length === 0
		) {
			setError('Firstname, lastname, and email cannot be empty string')
			return
		}

		const userInfo = localStorage.getItem('userInfo')
			? JSON.parse(localStorage.getItem('userInfo'))
			: null

		const payload = {}
		if (data.firstName !== user.firstName) payload.firstName = data.firstName
		if (data.lastName !== user.lastName) payload.lastName = data.lastName
		if (data.email !== user.email) payload.email = data.email

		setLoading(true)
		axios
			.patch(
				`${HYPER_API_BASE_URL}/api/users/permissions/update-personal-info`,
				payload,
				{
					headers: {
						Authorization: `Bearer ${userInfo.token}`,
					},
				}
			)
			.then((userData) => {
				const data = userData.data
				setUser({ ...userState, data })
				setLoading(false)
			})
			.catch(() => {
				setLoading(false)
				setError('Some error happened. Please try again')
			})
	}

	useEffect(() => {
		if (error.length > 0) {
			setTimeout(() => {
				setError('')
			}, 3000)
		}
	}, [error])

	return (
		<div className="w-full flex flex-col items-start gap-y-2">
			{error.length > 0 && (
				<div className="w-full flex justify-center">
					<ErrorMessage>{error}</ErrorMessage>
				</div>
			)}
			<h1 className="text-xl font-medium pr-2 leading-5 text-gray-800">
				Personal Information
			</h1>
			<div className="w-full flex flex-col lg:flex-row gap-y-3 lg:gap-x-6">
				<p className="text-sm leading-5 text-gray-600 w-full lg:w-80 flex-none">
					Information about the section could go here and a brief description of
					how this might be used.
				</p>
				<form
					onSubmit={handleSubmit(onSubmit)}
					className="w-full flex flex-col gap-y-5 bg-white border border-solid border-gray-700 rounded-sm px-3 py-2 md:px-4 md:py-3 lg:px-6 lg:pt-5 lg:pb-7"
				>
					<div className="w-full flex flex-col gap-y-3 pt-2">
						<div className="w-full flex flex-col md:flex-row md:justify-between gap-y-2 md:gap-x-3">
							<FormControl className="flex-grow">
								<div className="flex flex-col gap-y-1">
									<label
										className="text-sm leading-none text-gray-800"
										htmlFor="firstName"
									>
										First Name
									</label>
									<input
										id="firstName"
										{...register('firstName')}
										className="w-full max-w-md p-3 mt-1 bg-gray-100 border rounded border-gray-200 focus:outline-none focus:border-gray-600 text-sm  leading-none text-gray-800"
									/>
								</div>
							</FormControl>
							<FormControl className="flex-grow">
								<div className="flex flex-col gap-y-1">
									<label
										className="text-sm leading-none text-gray-800"
										htmlFor="lastName"
									>
										Last Name
									</label>
									<input
										id="lastName"
										{...register('lastName')}
										className="w-full max-w-md p-3 mt-1 bg-gray-100 border rounded border-gray-200 focus:outline-none focus:border-gray-600 text-sm  leading-none text-gray-800"
									/>
								</div>
							</FormControl>
						</div>
						<div className="w-full flex flex-col md:flex-row md:justify-between gap-y-2 md:gap-x-3">
							<FormControl className="flex-grow">
								<div className="flex flex-col gap-y-1">
									<label
										className="text-sm leading-none text-gray-800"
										htmlFor="email"
									>
										Email address
									</label>
									<input
										type="email"
										id="email"
										{...register('email')}
										className="w-full max-w-md p-3 mt-1 bg-gray-100 border rounded border-gray-200 focus:outline-none focus:border-gray-600 text-sm leading-none text-gray-800"
									/>
								</div>
							</FormControl>
						</div>
					</div>
					<div className="flex items-center justify-between md:justify-end gap-x-1 md:gap-x-3">
						<Button
							type="button"
							onClick={() => {
								reset({
									firstName: user.firstName,
									lastName: user.lastName,
									email: user.email,
								})
							}}
							className="form-button bg-transparent outline outline-1 hover:outline-2 active:outline-2 focus:outline-none focus:ring focus:ring-hyper-dark-blue h-12"
						>
							<span className="font-[400] leading-6">Reset</span>
						</Button>
						<Button
							type="submit"
							disabled={
								loading ||
								(watch('firstName') === user.firstName &&
									watch('lastName') === user.lastName &&
									watch('email') === user.email)
							}
							className="form-button bg-light-green hover:bg-green active:bg-green focus:outline-none focus:ring focus:ring-green h-12"
						>
							<span className="font-[600] leading-6 text-white">
								{loading ? 'Saving...' : 'Submit'}
							</span>
						</Button>
					</div>
				</form>
			</div>
		</div>
	)
}

export default AccountPersonalInfoSettings
