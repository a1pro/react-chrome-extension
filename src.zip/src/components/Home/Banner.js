import React, { useEffect, useState } from 'react'
import Thumbnail from '../../assets/banner-thumbnail.jpg'
const Banner = () => {
	const [innerWidth, setInnerWidth] = useState(window.innerWidth)

	useEffect(() => {
		addEventListener('resize', (event) => {
			updateWidth(event.target.innerWidth)
		})
		return () => removeEventListener('resize', updateWidth(window.innerWidth))
	})

	const updateWidth = (width) => {
		setInnerWidth(width)
	}

	return (
		<div>
			<section className="banner">
				<div className="container">
					<figure>
						<img src={Thumbnail} />
					</figure>
					<div className="bdesk">
						<div className="banner-content">
							<h1>Start or Scale</h1>
							<h1>your business</h1>
							<h1>with Hyper Speed</h1>
							<p className="banner-subtitle-text">
								Hyper{"'"}s solutions power your business to make smart,
								technology assisted decisions to maximize your performance,
								profits, and ability to scale.
							</p>
						</div>
					</div>
				</div>
				{innerWidth < 767 && (
					<div className="mobile-subtitle-text-container">
						<div className="text-xl mobile-subtitle-text text-center px-4 pt-8">
							Hyper{"'"}s solutions power your business to make smart,
							ai-assisted decisions to maximize your performance, profits, and
							ability to scale.
						</div>
					</div>
				)}
			</section>
		</div>
	)
}

export default Banner
