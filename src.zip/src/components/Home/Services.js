import React from 'react'

const Services = ({ servicesData }) => {
	return (
		<div id="services" className="text-center">
			<div className="overlayer">
				<div className="container">
					<div className="section-title mb-12">
						<h2>Our Services</h2>
					</div>
					<div className="row">
						{servicesData
							? servicesData.map((servicesItem, i) => (
									<div
										key={`${servicesItem.name}-${i}`}
										className="col-sm-12 col-md-6 col-lg-4"
									>
										{' '}
										<i className={servicesItem.icon}></i>
										<div className="service-desc">
											<h3>{servicesItem.name}</h3>
											<p className="text-justify">{servicesItem.text}</p>
										</div>
									</div>
							  ))
							: 'loading'}
					</div>
				</div>
			</div>
		</div>
	)
}

export default Services
