import React, { useState } from 'react'
import SuccessMessage from '../SuccessMesage/SuccessMessage'
import ErrorMessage from '../ErrorMessage/ErrorMessage'
import axios from 'axios'

const Contact = ({ contactData }) => {
	const [name, setName] = useState('')
	const [email, setEmail] = useState('')
	const [subject, setSubject] = useState('')
	const [text, setText] = useState('')
	const [success, setSuccess] = useState(null)
	const [error, setError] = useState(null)

	const handleSubmit = async (e) => {
		e.preventDefault()
		try {
			const BASE_URL =
				process.env.HYPER_API_BASE_URL ||
				'https://hyper-api-proto.herokuapp.com'
			const { data } = await axios.post(`${BASE_URL}/api/contact-us`, {
				name,
				email,
				subject,
				message: text,
			})
			setName('')
			setEmail('')
			setSubject('')
			setText('')
			setSuccess(data.message)
		} catch (err) {
			const errMessage =
				err.response && err.response.data.message
					? err.response.data.message
					: err.message
			setError(errMessage)
		}
	}

	return (
		<div>
			<div id="contact">
				<div className="container">
					<div className="col-md-8">
						<div className="row">
							<div className="section-title">
								{success && <SuccessMessage>{success}</SuccessMessage>}
								{error && <ErrorMessage>{error}</ErrorMessage>}
								<h2>Get In Touch</h2>

								<p className="text-justify">
									Please fill out the form below to send us an email and we will
									get back to you as soon as possible.
								</p>
							</div>
							<form name="sentMessage" onSubmit={handleSubmit}>
								<div className="row">
									<div className="col-md-8">
										<div className="form-group">
											<input
												type="text"
												id="name"
												name="name"
												className="form-control"
												placeholder="Name"
												required
												value={name}
												onChange={(e) => setName(e.target.value)}
											/>
											<p className="help-block text-danger"></p>
										</div>
									</div>
									<div className="col-md-8">
										<div className="form-group">
											<input
												type="email"
												id="email"
												name="email"
												className="form-control"
												placeholder="Email"
												required
												value={email}
												onChange={(e) => setEmail(e.target.value)}
											/>
											<p className="help-block text-danger"></p>
										</div>
									</div>
									<div className="col-md-8">
										<div className="form-group">
											<input
												type="text"
												id="subject"
												name="subject"
												className="form-control"
												placeholder="Subject"
												required
												value={subject}
												onChange={(e) => setSubject(e.target.value)}
											/>
											<p className="help-block text-danger"></p>
										</div>
									</div>
								</div>
								<div className="form-group">
									<textarea
										name="message"
										id="message"
										className="form-control"
										rows="4"
										placeholder="Message"
										required
										value={text}
										onChange={(e) => setText(e.target.value)}
									></textarea>
									<p className="help-block text-danger"></p>
								</div>
								<div id="success"></div>
								<button type="submit" className="btn-custom btn-lg">
									Send Message
								</button>
							</form>
						</div>
					</div>
					<div className="col-md-3 col-md-offset-1 contact-info">
						<div className="contact-item">
							<h3>Contact Info</h3>
							<p>
								<span>
									<i className="fa fa-map-marker"></i> Address
								</span>
								{contactData ? contactData.address : 'Address not found'}
							</p>
						</div>
						<div className="contact-item">
							<p>
								<span>
									<i className="fa fa-phone"></i> Phone
								</span>{' '}
								{contactData ? contactData.phone : 'Phone not found'}
							</p>
						</div>
						<div className="contact-item">
							<p>
								<span>
									<i className="fa fa-envelope-o"></i> Email
								</span>{' '}
								{contactData ? contactData.email : 'Email not found'}
							</p>
						</div>
					</div>
					<div className="col-md-12">
						<div className="row">
							<div className="social">
								<ul>
									<li>
										<a href={contactData ? contactData.instagram : '/'}>
											<i className="fa fa-instagram"></i>
										</a>
									</li>
									<li>
										<a href={contactData ? contactData.twitter : '/'}>
											<i className="fa fa-twitter"></i>
										</a>
									</li>
									<li>
										<a href={contactData ? contactData.youtube : '/'}>
											<i className="fa fa-youtube"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default Contact
