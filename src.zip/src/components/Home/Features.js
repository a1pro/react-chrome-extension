import React from 'react'

const Features = ({ featuresData }) => {
	return (
		<div id="features" className="text-center mt-4">
			<div className="">
				<div className="col-md-12 col-md-offset-1 section-title">
					<h2 className="mb-12">Features</h2>
				</div>
				<div className="row pt-2 px-24">
					{featuresData
						? featuresData.map((featuresItem, i) => (
								<div
									key={`${featuresItem.title}-${i}`}
									className="col-xs-12 col-sm-12 col-md-6 col-lg-4 px-8 pt-4"
								>
									{' '}
									<i className={featuresItem.icon}></i>
									<h3 className="feature-title">{featuresItem.title}</h3>
									<p>{featuresItem.text}</p>
								</div>
						  ))
						: 'Loading...'}
				</div>
			</div>
		</div>
	)
}

export default Features
