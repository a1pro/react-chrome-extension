import React from 'react'
import about from '../../assets/testimonial-photo.jpg'

const About = ({ aboutData }) => {
	return (
		<div id="about">
			<div className="container">
				<h2 className="text-center">About Us</h2>
				<div className="row">
					<div className="col-md-12 col-lg-6 flex justify-center mt-4">
						{' '}
						<img src={about} className="img-responsive" alt="about" />{' '}
					</div>
					<div className="col-md-12 col-lg-6 mt-4">
						<div className="about-text">
							<p className="text-justify text-base">
								{aboutData ? aboutData.paragraph : 'loading...'}
							</p>
							<h3>Why Choose Us?</h3>
							<div className="list-style">
								<div className="row">
									<div className="col-lg-6 col-sm-6 col-xs-12 flex justify-start">
										<ul className="p-0">
											{aboutData
												? aboutData.whyUs1.map((whyUsItem1, i) => (
														<li key={`${whyUsItem1}-${i}`}>{whyUsItem1}</li>
												  ))
												: 'loading'}
										</ul>
									</div>
									<div className="col-lg-6 col-sm-6 col-xs-12 flex justify-start sm:flex sm:justify-end">
										<ul className="p-0">
											{aboutData
												? aboutData.whyUs2.map((whyUsItem2, i) => (
														<li key={`${whyUsItem2}-${i}`}> {whyUsItem2}</li>
												  ))
												: 'loading'}
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default About
