import React from 'react'

const Team = ({ teamData }) => {
	return (
		<div id="team" className="text-center">
			<div className="container">
				<div className="col-md-offset-2 section-title">
					<h2>Meet the Team</h2>
					<p>
						Lorem ipsum dolor sit amet, consectetur adipiscing elit duis sed
						dapibus leonec.
					</p>
				</div>
				<div className="mt-12">
					<div className="row">
						{teamData
							? teamData.map((teamItem, i) => (
									<div
										key={`${teamItem.name}-${i}`}
										className="col-sm-6 col-md-6 col-lg-3"
									>
										<div className="thumbnail">
											{' '}
											<img src={teamItem.img} alt="..." className="team-img" />
											<div className="caption">
												<h4>{teamItem.name}</h4>
												<p>{teamItem.job}</p>
											</div>
										</div>
									</div>
							  ))
							: 'loading'}
					</div>
				</div>
			</div>
		</div>
	)
}

export default Team
