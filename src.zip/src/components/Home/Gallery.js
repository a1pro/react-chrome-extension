import React from 'react'
import Image from './Image'

const Gallery = ({ galleryData }) => {
	return (
		<div id="portfolio" className="text-center">
			<div className="container">
				<div className="section-title">
					<h2>Application Gallery</h2>
					<p>Explore the different automation products we offer</p>
				</div>
				<div className="portfolio-items">
					<div className="row">
						{galleryData
							? galleryData.map((galleryItem, i) => (
									<div
										key={`${galleryItem.title}-${i}`}
										className="col-sm-6 col-md-4 col-lg-4"
									>
										<Image
											title={galleryItem.title}
											largeImage={galleryItem.largeImage}
											smallImage={galleryItem.smallImage}
										/>
									</div>
							  ))
							: 'Loading...'}
					</div>
				</div>
			</div>
		</div>
	)
}

export default Gallery
