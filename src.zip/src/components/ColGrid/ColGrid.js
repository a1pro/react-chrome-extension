import React from 'react'
const ColGrid = ({ children }) => {
	return (
		<>
			<div className="2xl:container 2xl:mx-auto px-8">
				<div className="flex flex-wrap">
					<div className="w-full">
						{children}
						<div className="rounded" />
					</div>
				</div>
			</div>
		</>
	)
}
export default ColGrid
