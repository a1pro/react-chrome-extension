import './Dropdown.css'
import React, { useEffect, useState } from 'react'

const Dropdown = ({ items = [], size, onSelection }) => {
	const [selectedMarketplace, setSelectedMarketplace] = useState({
		label: 'US',
		icon: 'fi fi-us',
		value: 'ATVPDKIKX0DER',
	})
	const [showDropdownMenu, setShowDropdownMenu] = useState(false)

	const onSelect = (event, marketplace) => {
		onSelection(marketplace)
		setSelectedMarketplace(marketplace)
		setShowDropdownMenu(!showDropdownMenu)
		const targetText = event.target?.innerText
		if (document.getElementById('selected-item-label')) {
			document.getElementById('selected-item-label').innerText = targetText
		}
	}

	const dropdownItems = items.map((item) => {
		return (
			<button
				key={item.value}
				onClick={(event) => {
					event.stopPropagation()
					onSelect(event, item)
				}}
				value={item.value}
				className="w-full flex items-center justify-between hover:bg-gray-100 text-gray-600 hover:text-gray-800 p-3 hover:font-bold hover:cursor-default"
			>
				<div className="flex w-full items-stretch">
					<span className={`w-6 ${item.icon}`}></span>
					<div className="pl-4 text-sm w-fit">{item.label}</div>
				</div>
			</button>
		)
	})

	return (
		<>
			<div className={`${size}`}>
				<div className="lg:max-w-[356px] md:max-w-[356px] max-w-[343px] mx-auto">
					<div className="dropdown-one w-full rounded outline-none bg-white relative mt-2 shadow-md">
						<button
							onClick={(event) => {
								event.preventDefault()
								event.stopPropagation()
								setShowDropdownMenu(!showDropdownMenu)
							}}
							className="relative px-4 py-[12px] flex items-center justify-between w-full shadow-sm"
						>
							<div className="flex w-full items-stretch">
								<span className={`w-6 ${selectedMarketplace.icon}`}></span>
								<span
									className="pl-4 text-gray-600 text-sm font-bold"
									id="selected-item-name"
								>
									{selectedMarketplace.label}
								</span>
							</div>
							{/* TODO: revisit this to make carat flip when dropdown drawer opens and closes
								<div className="relative">
								<svg
									className="mt-2 absolute"
									width={12}
									height={8}
									viewBox="0 0 12 8"
									fill="none"
									xmlns="http://www.w3.org/2000/svg"
								>
									<path
										d="M1.06216 1.9393L5.43028 7.0368C5.50069 7.11892 5.58803 7.18484 5.68631 7.23003C5.78459 7.27522 5.89148 7.29862 5.99966 7.29862C6.10783 7.29862 6.21472 7.27522 6.313 7.23003C6.41128 7.18484 6.49862 7.11892 6.56903 7.0368L10.9372 1.9393C11.354 1.45273 11.0084 0.701172 10.3678 0.701172H1.63028C0.989656 0.701172 0.644031 1.45273 1.06216 1.9393Z"
										fill="#1F2937"
									/>
								</svg>
							</div> */}
						</button>
						{showDropdownMenu && (
							<div
								className="z-10 w-full py-2 absolute top-12 right-0 bg-white"
								id="dropdown-item"
							>
								{dropdownItems}
							</div>
						)}
					</div>
				</div>
			</div>
		</>
	)
}

export default Dropdown
