import './Header.css'
import React, { useRef, useState } from 'react'
import { Search, useNavigate } from 'react-router-dom'
import Logo from '../../assets/logo.png'
import { ReactComponent as SearchSvg } from '../../assets/search.svg'
import userState from '../../recoil/user'
import { useResetRecoilState, useRecoilValue } from 'recoil'

export const Header = ({ isAuthenticated = false }) => {
	const [rotate, setRotate] = useState(false)
	const [show, setShow] = useState(false)
	const { firstName, email } = useRecoilValue(userState)
	const resetUserState = useResetRecoilState(userState)
	const history = useNavigate()
	const inputRef1 = useRef(null)
	const inputRef2 = useRef(null)
	const inputRef3 = useRef(null)

	const logout = (e) => {
		resetUserState()
		localStorage.removeItem('userInfo')
		history('/login')
	}

	const onKeyDown = (event) => {
		const target = event.target
		const value = target.value.trim()

		if (value.length > 0) {
			if (event.key === 'Enter') {
				history(`/product?productId=${value}`)
			}
		}
	}

	const onSearchIconClick = (ref) => {
		if (ref && ref.current) {
			const value = ref.current.value

			if (value.length > 0) history(`/product?productId=${value}`)
		}
	}

	return (
		<>
			<div className="fixed w-full z-20 top-0">
				<div className="bg-gray-200">
					<div className="h-full relative">
						<div className="bg-white">
							<div>
								<nav>
									<div className="header flex flex-row justify-between  items-center py-10">
										<div className="logo-container flex space-x-3 items-center lg:pl-7 sm:pl-6 pl-4 pr-8">
											<button
												className="h-12 w-16"
												onClick={() => history('/')}
											>
												<img src={Logo} className="h-12 w-16" />
											</button>
										</div>
										{/* For large (i.e. desktop and laptop sized screen) */}
										{isAuthenticated && (
											<div className="search-bar-container lg:flex hidden flex-auto justify-between flex-row px-7 py-2">
												<div className="search-bar focus:outline-none focus:ring foucs:ring-offset-2 focus:ring-gray-800 bg-gray-50 flex items-center px-1 py-1 space-x-3 rounded border border-solid border-gray-800">
													<input
														aria-label="Search Bar"
														className="search-bar-input focus:outline-none w-72 bg-gray-50 font-normal text-sm leading-4 text-gray-500 placeholder-gray-500 px-2 py-2"
														type="text"
														placeholder="Search Keyword, ASIN, GTIN, or UPC"
														onKeyDown={onKeyDown}
														ref={inputRef1}
													/>
													<div
														className="h-full flex items-center pr-2 cursor-pointer"
														onClick={() => {
															onSearchIconClick(inputRef1)
														}}
													>
														<SearchSvg className="svg" />
													</div>
												</div>
											</div>
										)}

										<div className=" hidden sm:flex justify-end flex-row lg:pr-7 sm:pr-6 pr-4 pl-8">
											{isAuthenticated && (
												<>
													<div className="cursor-pointer focus:outline-none focus:ring focus:ring-offset-2 focus:ring-gray-800 relative flex justify-center items-center xl:mr-8 mr-6">
														<svg
															width={24}
															height={24}
															viewBox="0 0 24 24"
															fill="none"
															xmlns="http://www.w3.org/2000/svg"
														>
															<path
																d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z"
																stroke="#1F2937"
																strokeWidth="1.5"
																strokeLinecap="round"
																strokeLinejoin="round"
															/>
															<path
																d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21"
																stroke="#1F2937"
																strokeWidth="1.5"
																strokeLinecap="round"
																strokeLinejoin="round"
															/>
														</svg>
														<div className="animate-ping w-1.5 h-1.5 bg-indigo-700 rounded-full absolute top-1 right-0 m-auto duration-200" />
														<div className=" w-1.5 h-1.5 bg-indigo-700 rounded-full absolute top-1 right-0 m-auto shadow-lg" />
													</div>
													<div className=" flex justify-center items-center flex-row">
														<img
															className="profile-image w-10 h-10 "
															src="https://i.ibb.co/QMddNDb/Ellipse-14.png"
															alt="individual person image-3"
														/>
														<div className="ml-2 mr-2">
															<p className="user-info text-lg leading-4 font-semibold text-gray-800">
																{firstName}
															</p>
															<p className="user-info font-normal text-xs leading-3 text-gray-600 mt-1">
																{email}
															</p>
														</div>
														<div>
															<button onClick={logout}>Logout</button>
														</div>
													</div>
												</>
											)}
										</div>
										{/* Burger Icon */}
										<div
											id="bgIcon"
											onClick={() => setShow(!show)}
											className=" focus:outline-none focus:ring focus:ring-offset-2 focus:ring-gray-800 block sm:hidden cursor-pointer lg:pr-7 sm:pr-6 py-6 pr-4"
										>
											<svg
												className={`${show ? 'hidden' : ''}`}
												width={24}
												height={24}
												viewBox="0 0 24 24"
												fill="none"
												xmlns="http://www.w3.org/2000/svg"
											>
												<path
													className=" transform duration-150"
													d="M4 6H20"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
												<path
													d="M4 12H20"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
												<path
													className=" transform duration-150"
													d="M4 18H20"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
											</svg>
											<svg
												className={`${show ? '' : 'hidden'} `}
												width={24}
												height={24}
												viewBox="0 0 24 24"
												fill="none"
												xmlns="http://www.w3.org/2000/svg"
											>
												<path
													d="M18 6L6 18"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
												<path
													d="M6 6L18 18"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
											</svg>
										</div>
									</div>
									{/* for medium-sized devices */}
									<div className="lg:hidden hidden sm:flex flex-col lg:px-7 sm:px-6 px-4 ">
										<hr className=" w-full bg-gray-200 " />
										<div className="lg:hidden flex flex-auto justify-between mt-3 flex-row pb-4">
											<div>
												<p className=" font-normal text-xs leading-3 text-gray-600">
													Hi David
												</p>
												<h3 className=" font-bold text-xl leading-5 text-gray-800 mt-2">
													Welcome Back
												</h3>
											</div>
											<div className=" focus:outline-none focus:ring foucs:ring-offset-2 focus:ring-gray-800 bg-gray-50 flex items-center px-1 py-1 space-x-3 rounded border border-solid border-gray-800">
												<input
													aria-label="Search Bar"
													className=" focus:outline-none w-44 lg:w-56 xl:w-64 bg-gray-50 font-normal text-sm leading-4 text-gray-500 placeholder-gray-500 px-2 py-2"
													type="text"
													placeholder="Search"
													onKeyDown={onKeyDown}
													ref={inputRef2}
												/>
												<div
													className="h-full flex items-center pr-2 cursor-pointer"
													onClick={() => {
														onSearchIconClick(inputRef2)
													}}
												>
													<SearchSvg className="svg" />
												</div>
											</div>
										</div>
									</div>
								</nav>
							</div>
						</div>
						{/* Mobile and Small devices Navigation */}
						<div
							id="MobileNavigation"
							className={`${
								show ? '' : 'hidden'
							} transform duration-150 sm:hidden h-full bg-white `}
						>
							<div className="flex flex-col justify-between h-auto ">
								<div className="flex flex-col lg:px-7 sm:px-6 px-4">
									<hr className="w-full bg-gray-200 " />
									<div className="lg:hidden flex flex-auto justify-between mt-3 flex-row pb-4">
										<div>
											<p className="font-normal text-xs leading-3 text-gray-600">
												Hi {firstName}
											</p>
											<h3 className="font-bold text-xl leading-5 text-gray-800 mt-2">
												Welcome Back
											</h3>
										</div>
										<div className="cursor-pointer relative flex justify-center items-center">
											<svg
												width={24}
												height={24}
												viewBox="0 0 24 24"
												fill="none"
												xmlns="http://www.w3.org/2000/svg"
											>
												<path
													d="M18 8C18 6.4087 17.3679 4.88258 16.2426 3.75736C15.1174 2.63214 13.5913 2 12 2C10.4087 2 8.88258 2.63214 7.75736 3.75736C6.63214 4.88258 6 6.4087 6 8C6 15 3 17 3 17H21C21 17 18 15 18 8Z"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
												<path
													d="M13.73 21C13.5542 21.3031 13.3019 21.5547 12.9982 21.7295C12.6946 21.9044 12.3504 21.9965 12 21.9965C11.6496 21.9965 11.3054 21.9044 11.0018 21.7295C10.6982 21.5547 10.4458 21.3031 10.27 21"
													stroke="#1F2937"
													strokeWidth="1.5"
													strokeLinecap="round"
													strokeLinejoin="round"
												/>
											</svg>
											<div className="animate-ping w-1.5 h-1.5 bg-indigo-700 rounded-full absolute top-1 right-0 m-auto duration-200" />
											<div className=" w-1.5 h-1.5 bg-indigo-700 rounded-full absolute top-1 right-0 m-auto shadow-lg" />
										</div>
									</div>
									<div className=" w-auto sm:w-96 focus:outline-none focus:ring foucs:ring-offset-2 focus:ring-gray-800 bg-gray-50 flex items-center space-x-3 rounded mt-4 px-1 py-1 border border-solid border-gray-800">
										<input
											aria-label="Search Bar"
											className=" focus:outline-none w-full bg-gray-50 font-normal pl-2 text-sm leading-4 px-2 py-2 text-gray-500 placeholder-gray-500 "
											type="text"
											placeholder="Search"
											onKeyDown={onKeyDown}
											ref={inputRef3}
										/>
										<div
											className="h-full flex items-center pr-2 cursor-pointer"
											onClick={() => {
												onSearchIconClick(inputRef3)
											}}
										>
											.
											<SearchSvg className="svg" />
										</div>
									</div>
								</div>
								<div className="flex items-center flex-row py-6 px-8 bg-gray-100 absolute bottom-0 left-0 w-full">
									<img
										className="w-10 h-10 "
										src="https://i.ibb.co/QMddNDb/Ellipse-14.png"
										alt="individual person image-3"
									/>
									<div className="ml-2">
										<p className="text-lg leading-4 font-semibold text-gray-800">
											{firstName}
										</p>
										<p className="font-normal text-xs leading-3 text-gray-600 mt-1">
											{email}
										</p>
									</div>
									<svg
										onClick={() => setRotate(!rotate)}
										className="cursor-pointer transform duration-100 xl:ml-7 ml-3.5 focus:outline-none focus:ring focus:ring-offset-2 focus:ring-gray-800 "
										width={14}
										height={8}
										viewBox="0 0 14 8"
										fill="none"
										xmlns="http://www.w3.org/2000/svg"
									>
										<path
											d="M1 1L7 7L13 1"
											stroke="#1F2937"
											strokeWidth="1.5"
											strokeLinecap="round"
											strokeLinejoin="round"
										/>
									</svg>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Header
