import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react'

import './AgGrid.css'

import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/styles/ag-grid.css' // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css' // Optional theme CSS
import numberWithCommas from '../../utils/helpers/number-formatter.util'
const AgGrid = ({ data, gridOptions, downloadExcel }) => {
	// const gridRef = useRef() // Optional - for accessing Grid's API
	return (
		<>
			<div className="grid-container ag-theme-alpine border m-top bg-white h-screen">
				<div className="t-head">
					<div className="thLeft">
						Displaying
						<select className="s-box">
							{/* <option value="">10</option> */}
							<option value="">{data?.products?.length}</option>
						</select>
						of {numberWithCommas(data?.numberOfResults) || 'Unknown'}
					</div>
					<div className="th-right">
						<button
							onClick={() => downloadExcel(data)}
							className="download-btn bg-hyper-dark-blue focus:outline-none w-full transition duration-150 ease-in-out rounded text-zinc-50 px-8 mr-3 text-sm"
						>
							Download CSV
							<img className="ml-2" src="ico/download-ico.svg" />
						</button>
						{/* <button
							onClick={() => downloadExcel(data)}
							className="download-btn"
						>
							Download CSV
							<img src="ico/download-ico.svg" />
						</button> */}
						{/* Page <input type="text" value="1" className="t-box" />
						of 89,455 */}
						<button className="ml-2 mr-2 arrow">
							{' '}
							<img src="ico/left-arrow-ico.svg" />{' '}
						</button>
						<button className="ml-2 mr-2 arrow">
							{' '}
							<img src="ico/right-arrow-ico.svg" />{' '}
						</button>
						|{' '}
						<button className="ml-2 mr-2 calender-btn">
							<img src="ico/calendar.png" />
						</button>
					</div>
				</div>
				<div className="res-table">
					<AgGridReact
						style={{ width: '100%', height: '100%' }}
						gridOptions={gridOptions}
					/>
				</div>
			</div>
		</>
	)
}

export default AgGrid
